﻿// Execução.

List<Curso> cursos = new List<Curso>()
{

    // Os cursos podem existir sem ter alunos (Independência).

    new Curso("DSM"),
    new Curso("SI"),
    new Curso("GTI")

};

Aluno aluno = new Aluno("Pablo Valentin", cursos[0]);

aluno.Matricular(cursos[2]);

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine($"Aluno: {aluno.Nome}.");

Console.WriteLine($"\nMatrículas ({aluno.Nome}):\n");

foreach (Curso curso in aluno.Cursos)
{

    Console.WriteLine($"- {curso.Nome}");

}

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Classes.

class Aluno
{

    public string? Nome { get; set; }

    public List<Curso> Cursos { get; set; } = new List<Curso>();

    public Aluno(string nome, Curso curso)
    {

        this.Nome = nome;

        this.Cursos.Add(curso);

    }

    public void Matricular(Curso curso)
    {

        this.Cursos.Add(curso);

    }

}

class Curso
{

    public string? Nome { get; set; }

    public Curso(string nome)
    {

        this.Nome = nome;

    }

}