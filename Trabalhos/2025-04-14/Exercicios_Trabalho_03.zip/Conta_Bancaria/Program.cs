﻿// Execução.

try
{

    Conta_Bancaria conta_bancaria = new Conta_Bancaria(100.00);

    conta_bancaria.Detalhes();

    conta_bancaria.Depositar(100);

    conta_bancaria.Detalhes();

    conta_bancaria.Sacar(200);

    conta_bancaria.Detalhes();

    conta_bancaria.Sacar(10); // Será gerada uma exceção personalizada.

}

catch (SaldoInsuficienteException ex)
{

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine($"Saída: {ex.Message}");

}

catch (Exception ex)
{

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine($"Saída: {ex.Message}");

}

finally
{

    Console.WriteLine("---------------------------------------------------------------");

    Console.ReadKey();

}

// Classe.

class Conta_Bancaria
{

    private double saldo;

    // Inpedindo a alteração do valor manualmente, por questão de segurança.

    public double Saldo { get { return this.saldo; } } // Somente leitura.

    public Conta_Bancaria(double saldo)
    {

        this.saldo = saldo;

    }

    public void Detalhes()
    {

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("Saldo atual: {0}.", this.Saldo.ToString("C2"));

    }

    public void Sacar(double valor)
    {

        if (this.Saldo >= valor)
        {

            Console.WriteLine("---------------------------------------------------------------");

            this.saldo -= valor;

            Console.WriteLine($"Saque ({valor.ToString("C2")}) efetuado com sucesso.");

        }

        else
        {

            throw new SaldoInsuficienteException($"Não há o suficiente ({valor.ToString("C2")}) para efetuar o saque.");

        }

    }

    public void Depositar(double valor)
    {

        Console.WriteLine("---------------------------------------------------------------");

        this.saldo += valor;

        Console.WriteLine($"Depósito ({valor.ToString("C2")}) efetuado com sucesso.");

    }

}

// Exceção.

class SaldoInsuficienteException : Exception
{

    public SaldoInsuficienteException(string message) : base(message) {  }

}