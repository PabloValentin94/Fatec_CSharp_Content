﻿// Execução.

Funcionario funcionario = new Funcionario("Thiago", 1512.01);

funcionario.Detalhes();

funcionario.Obedecer();

Gerente gerente = new Gerente("Pablo", "G001-12345678910", 8000.50);

gerente.Detalhes();

gerente.Mandar();

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Interface.

public interface IFuncionario
{

    public string? Nome { get; set; }

    public double Salario { get; set; }

    public void Detalhes();

}

// Classes.

public class Funcionario : IFuncionario
{

    public string? Nome { get; set; }

    public double Salario { get; set; }

    public Funcionario(string nome, double salario)
    {

        this.Nome = nome;

        this.Salario = salario;

    }

    public void Detalhes()
    {

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("FUNCIONÁRIO");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Nome: {this.Nome};" +
                          $"\n\nSalário: {this.Salario.ToString("C2")}");

    }

    public void Obedecer()
    {

        Console.WriteLine("\nO funcionário deve obedecer o seu gerente.");

    }

}

public class Gerente : IFuncionario
{

    public string? Nome { get; set; }

    public string? Passaporte_Corporativo { get; set; }

    public double Salario { get; set; }

    public Gerente(string nome, string passaporte_corporativo, double salario)
    {

        this.Nome = nome;

        this.Passaporte_Corporativo = passaporte_corporativo;

        this.Salario = salario;

    }

    public void Detalhes()
    {

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("GERENTE");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Nome: {this.Nome};" +
                          $"\n\nPassaporte Corporativo: {this.Passaporte_Corporativo};" +
                          $"\n\nSalário: {this.Salario.ToString("C2")}");

    }

    public void Mandar()
    {

        Console.WriteLine("\nO gerente deve atribuir funções para seus funcionários.");

    }

}