﻿// Execução.

List<Aluno> alunos = new List<Aluno>()
{

    new Aluno("Pablo Valentin", "0201392411022"),
    new Aluno("Thiago Figueredo", "0201392411023"),
    new Aluno("Victor Hugo", "0201392411069")

};

List<Disciplina> disciplinas = new List<Disciplina>()
{

    new Disciplina("UI Design", "DSM", "Anderson"),
    new Disciplina("Banco de Dados Relacional", "DSM", "Wudson"),
    new Disciplina("Banco de Dados Não Relacional", "DSM", "Tiago")

};

List<Matricula> matriculas = new List<Matricula>();

matriculas.Add(alunos[0].Matricular("05/02/2024", disciplinas[0]));
matriculas.Add(alunos[0].Matricular("05/08/2024", disciplinas[1]));
matriculas.Add(alunos[0].Matricular("05/02/2025", disciplinas[2]));

matriculas.Add(alunos[1].Matricular("05/02/2024", disciplinas[0]));
matriculas.Add(alunos[1].Matricular("05/08/2024", disciplinas[1]));
matriculas.Add(alunos[1].Matricular("05/02/2025", disciplinas[2]));

matriculas.Add(alunos[2].Matricular("05/02/2024", disciplinas[0]));
matriculas.Add(alunos[2].Matricular("05/08/2024", disciplinas[1]));
matriculas.Add(alunos[2].Matricular("05/02/2025", disciplinas[2]));

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("ALUNOS E AS DISCIPLINAS QUE EXECUTAM");

Console.Write("---------------------------------------------------------------");

foreach (Aluno aluno in  alunos)
{

    aluno.Detalhes();

}

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("DISCIPLINAS E OS(AS) ALUNOS(AS) MATRICULADOS(AS) NELA");

Console.Write("---------------------------------------------------------------");

foreach (Disciplina disciplina in disciplinas)
{

    disciplina.Detalhes();

}

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("MATRÍCULAS");

Console.Write("---------------------------------------------------------------");

foreach (Matricula matricula in matriculas)
{

    matricula.Detalhes();

}

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Classes.

class Aluno
{

    public string? Nome { get; set; }

    public string? RA { get; set; }

    public List<Disciplina> Disciplinas_Executadas { get; set; } = new List<Disciplina>();

    public Aluno(string nome, string ra)
    {

        this.Nome = nome;

        this.RA = ra;

    }

    public Matricula Matricular(string data_matricula, Disciplina disciplina)
    {

        Matricula matricula = new Matricula(data_matricula, this, disciplina);

        disciplina.Alunos_Matriculados.Add(this);

        this.Disciplinas_Executadas.Add(disciplina);

        return matricula;

    }

    public void Detalhes()
    {

        Console.WriteLine("\n{0}:\n", this.Nome);

        foreach (Disciplina disciplina in this.Disciplinas_Executadas)
        {

            Console.WriteLine("- {0}", disciplina.Nome);

        }

    }

}

class Disciplina
{

    public string? Nome { get; set; }

    public string? Curso { get; set; }

    public string? Professor { get; set; }

    public List<Aluno> Alunos_Matriculados { get; set; } = new List<Aluno>();

    public Disciplina(string nome, string curso, string professor)
    {

        this.Nome = nome;

        this.Curso = curso;

        this.Professor = professor;

    }

    public void Detalhes()
    {

        Console.WriteLine("\n{0}:\n", this.Nome);

        foreach (Aluno aluno in this.Alunos_Matriculados)
        {

            Console.WriteLine("- {0}", aluno.Nome);

        }

    }

}

class Matricula
{

    public string? Data_Criacao { get; set; }

    public Aluno? Aluno { get; set; }

    public Disciplina? Disciplina { get; set; }

    public Matricula(string data_criacao, Aluno aluno, Disciplina disciplina)
    {

        this.Data_Criacao = data_criacao;

        this.Aluno = aluno;

        this.Disciplina = disciplina;

    }

    public void Detalhes()
    {

        Console.WriteLine("\nAluno: {0};", this.Aluno.Nome);

        Console.WriteLine("Disciplina: {0}.", this.Disciplina.Nome);

    }

}