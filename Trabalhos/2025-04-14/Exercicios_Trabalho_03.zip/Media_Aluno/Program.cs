﻿// Execução.

bool looping = true;

while (looping)
{

    try
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.Write("Insira quantas notas deseja adicionar: ");
        int quantidade_notas = int.Parse(Console.ReadLine() ?? "0");

        if (quantidade_notas <= 0)
        {

            throw new NumeroInvalidoAvaliacoesException("Insira um número válido de avaliações.");

        }

        double[] notas = new double[quantidade_notas];

        Console.Clear();

        for (int i = 0; i < notas.Length; i++)
        {

            Console.WriteLine("---------------------------------------------------------------");

            Console.Write("Insira a {0}ª nota: ", i + 1);
            notas[i] = double.Parse((Console.ReadLine() ?? "0,00").Replace(".", ","));

            if (notas[i] < 0 || notas[i] > 10)
            {

                throw new NotaForaIntervaloException("As notas passadas devem ser maiores ou iguais a 0 e menores ou iguais a 10.");

            }

        }

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        double media = 0;

        Console.WriteLine("Notas:\n");

        for (int j = 0; j < notas.Length; j++)
        {

            Console.Write("- {0}", notas[j]);

            media += notas[j];

            Console.Write((j < notas.Length - 1) ? ";\n" : ".\n");

        }

        media /= notas.Length;

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("Média: {0}.", media);

        Console.WriteLine("---------------------------------------------------------------");

        looping = false;

    }

    catch (FormatException ex)
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Insira um valor com um tipo válido!\n\nSaída: {ex.Message}");

    }

    catch (NumeroInvalidoAvaliacoesException ex)
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Saída: {ex.Message}");

    }

    catch (NotaForaIntervaloException ex)
    {

        Console.Clear();

        Console.WriteLine("-------------------------------------------------------------------------------------");

        Console.WriteLine($"Saída: {ex.Message}");

    }

    catch (Exception ex)
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Saída: {ex.Message}");

    }

    finally
    {

        Console.ReadKey();

    }

}

// Exceções.

class NumeroInvalidoAvaliacoesException : Exception
{

    public NumeroInvalidoAvaliacoesException(string message) : base(message) {  }

}

class NotaForaIntervaloException : Exception
{

    public NotaForaIntervaloException(string message) : base(message) {  }

}