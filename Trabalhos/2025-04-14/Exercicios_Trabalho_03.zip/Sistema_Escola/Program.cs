﻿// Execução.

List<Professor> professores = new List<Professor>()
{

    new Professor("Tiago", "Tiagotas", new string[3, 2] // Linhas X Colunas.
    {

        // Alunos.

        {"Pablo Valentin", "0201392411022"}, // Nome | RA.
        {"Vinícius Cassemira", "0201392411017"}, // Nome | RA.
        {"Thiago Figueredo", "0201392411035"} // Nome | RA.

    }),

    new Professor("Wudson", "Líder dos Animais", new string[3, 2] // Linhas X Colunas.
    {

        // Alunos.

        {"Vinícius Nascimento", "0201392411030"}, // Nome | RA.
        {"Vinícius Gimenes", "0201392411036"}, // Nome | RA.
        {"Lucas Nono", "0201392411018"} // Nome | RA.

    }),

    new Professor("Aparecida Maria", "Cida", new string[3, 2] // Linhas X Colunas.
    {

        // Alunos.

        {"Alissa Gabriel", "0201392411027"}, // Nome | RA.
        {"Evelyn Cassinotte", "0201392411004"}, // Nome | RA.
        {"Kieran Santos Corrêa", "0201392411003"} // Nome | RA.

    })

};

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("PROFESSORES E SEUS ALUNOS");

Console.Write("---------------------------------------------------------------");

foreach (Professor professor in professores)
{

    professor.Detalhes();

}

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Classes.

abstract class Pessoa
{

    public string? Nome { get; set; }

    public Pessoa(string nome)
    {

        this.Nome = nome;

    }

}

class Professor : Pessoa
{

    public string? Apelido { get; set; }

    public string[,] Alunos_Associados { get; set; } = new string[3, 2];

    public Professor(string nome, string apelido, string[,] alunos_associados) : base(nome)
    {

        this.Apelido = apelido;

        this.Alunos_Associados = alunos_associados;

    }

    public void Detalhes()
    {

        Console.WriteLine("\n{0} ({1}):\n", this.Nome, this.Apelido);

        for (int i = 0; i < this.Alunos_Associados.GetLength(0); i++)
        {

            Console.Write($"- {this.Alunos_Associados[i, 0]} ({this.Alunos_Associados[i, 1]})");

            Console.Write((i < this.Alunos_Associados.GetLength(0) - 1) ? ";\n" : ".\n");

        }

    }

}