﻿// Execução.

bool looping = true;

while (looping)
{

    try
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.Write("Digite um nome para o produto: ");
        string nome_produto = Console.ReadLine() ?? "";

        Console.Write("\nDigite o estoque disponível do produto: ");
        int estoque_produto = int.Parse(Console.ReadLine() ?? "0");

        Console.Write("\nDigite o preço do produto: ");
        double preco_produto = double.Parse((Console.ReadLine() ?? "0,00").Replace(".", ","));

        Produto produto = new Produto(nome_produto, estoque_produto, preco_produto);

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Produto cadastrado com sucesso.");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("Produto especificado:");

        Console.WriteLine("\nNome: {0};", produto.Nome);

        Console.WriteLine("\nEstoque: {0};", produto.Estoque);

        Console.WriteLine("\nPreço: {0}.", produto.Preco.ToString("C2"));

        Console.WriteLine("---------------------------------------------------------------");

        looping = false;

    }

    catch (FormatException ex)
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Insira um valor com um tipo válido!\n\nSaída: {ex.Message}");

    }

    catch (OverflowException ex)
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"O número passado não é suportado (Muito grande.)!\n\nSaída: {ex.Message}");

    }

    catch (Exception ex)
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Saída: {ex.Message}");

    }

    finally
    {

        Console.ReadKey();

    }

}

// Classe.

class Produto
{

    public string? Nome { get; set; }

    public int Estoque { get; set; }

    public double Preco { get; set; }

    public Produto(string nome, int estoque, double preco)
    {

        this.Nome = nome;

        this.Estoque = estoque;

        this.Preco = preco;

    }

}