﻿// Execução.

Console.WriteLine("---------------------------------------------------------------");

Pedido pedido = new Pedido("Camisa Polo", 2, 50);

Console.WriteLine("Quantidade atual de itens do pedido: {0}.", pedido.Itens.Count);

Console.WriteLine("---------------------------------------------------------------");

pedido.Adicionar_Item("Calça Jeans", 1, 80);

Console.WriteLine("Quantidade atual de itens do pedido: {0}.", pedido.Itens.Count);

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

//Classe.

public class Pedido
{

    // Quando o pedido for apagado, os itens dele serão descartados (Composição).

    public List<Item> Itens { get; set; } = new List<Item>();

    // Construtor.

    public Pedido(string nome_item, int quantidade_item, double preco_item)
    {

        /*
         
            Em uma composição, geralmente se instancia um objeto da classe associada dentro 
            da própria classe que irá conter esse objeto, ao invés de passá-lo como um 
            parâmetro. Por isso os parâmetros do construtor são os campos do objeto que será 
            instanciado, ao invés do próprio objeto.

         */

        this.Adicionar_Item(nome_item, quantidade_item, preco_item);

    }

    // Método.

    public void Adicionar_Item(string nome_item, int quantidade_item, double preco_item)
    {

        this.Itens.Add(new Item(nome_item, quantidade_item, preco_item));

        Console.WriteLine("Item ({0}) adicionado ao pedido com sucesso.", nome_item);

        Console.WriteLine("---------------------------------------------------------------");

    }

    // Classe (Só deve ser utilizada dentro de um pedido.).

    public class Item
    {

        public string? Nome { get; set; }

        public int Quantidade { get; set; }

        public double Preco { get; set; }

        public double Total_Item { get; set; }

        public Item(string nome, int quantidade, double preco)
        {

            this.Nome = nome;

            this.Quantidade = quantidade;

            this.Preco = preco;

            this.Total_Item = preco * quantidade;

        }

    }

}