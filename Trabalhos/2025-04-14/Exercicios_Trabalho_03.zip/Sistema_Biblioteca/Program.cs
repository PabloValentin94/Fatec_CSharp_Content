﻿// Execução.

List<Leitor> leitores = new List<Leitor>()
{

    new Leitor("Pablo Valentin", "Masculino"),
    new Leitor("Thiago Figueredo", "Masculino"),
    new Leitor("Evelyn Cassinotte", "Feminino")

};

List<Livro> livros = new List<Livro>()
{

    new Livro("Dom Quixote", "Romance", "Miguel de Cervantes"),
    new Livro("Hamlet", "Teatro", "Willian Shakespeare"),
    new Livro("Orgulho e Preconceito", "Romance", "Jane Austen"),
    new Livro("Harry Potter", "Fantasia", "J.K. Rowling"),
    new Livro("O Senhor dos Anéis", "Fantasia", "J.R.R. Tolkien")

};

List<Emprestimo> emprestimos = new List<Emprestimo>();

emprestimos.Add(livros[0].Alugar("10/04/2025", leitores[2])); // Criando um empréstimo.

emprestimos.Add(livros[3].Alugar("15/04/2025", leitores[0])); // Criando um empréstimo.

emprestimos.Add(livros[4].Alugar("10/04/2025", leitores[1])); // Criando um empréstimo.

emprestimos.Add(livros[2].Alugar("20/04/2025", leitores[2])); // Criando um empréstimo.

Emprestimo? demonstracao_validacao = livros[0].Alugar("10/04/2025", leitores[1]);

if (demonstracao_validacao == null)
{

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("ERRO PROPOSITAL");

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("Não foi possível alugar o livro especificado.");

    Console.WriteLine("---------------------------------------------------------------");

    Console.ReadKey();

    Console.Clear();

}

livros[2].Devolver(leitores[2]); // Devolvendo um livro.

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("LEITORES(AS)");

Console.Write("---------------------------------------------------------------");

foreach (Leitor leitor in leitores)
{

    leitor.Detalhes();

}

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("LIVROS");

Console.Write("---------------------------------------------------------------");

foreach (Livro livro in livros)
{

    livro.Detalhes();

}

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("EMPRÉSTIMOS");

Console.Write("---------------------------------------------------------------");

foreach (Emprestimo emprestimo in emprestimos)
{

    // Os empréstimos já fechados também serão exibidos.

    emprestimo.Detalhes();

}

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Classes.

abstract class Pessoa
{

    public string? Nome { get; set; }

    public string? Sexo { get; set; }

    public Pessoa(string nome, string sexo)
    {

        this.Nome = nome;

        this.Sexo = sexo;

    }

}

class Leitor : Pessoa
{

    public List<Livro> Livros_Alugados { get; set; } = new List<Livro>();

    public Leitor(string nome, string sexo) : base(nome, sexo) {  }

    public void Detalhes()
    {

        Console.WriteLine("\nNome: {0};", this.Nome);

        Console.WriteLine("Sexo: {0};", this.Sexo);

        string livros = "";

        for (int i = 0; i < this.Livros_Alugados.Count; i++)
        {

            livros += this.Livros_Alugados[i].Nome;

            if (i < this.Livros_Alugados.Count - 1)
            {

                livros += ", ";

            }

        }

        Console.WriteLine("Livros Alugados: {0}.", livros);

    }

}

class Livro
{

    public string? Nome { get; set; }

    public string? Genero { get; set; }

    public string? Autor { get; set; }

    public string? Status { get; set; }

    public Livro(string nome, string genero, string autor)
    {

        this.Nome = nome;

        this.Genero = genero;

        this.Autor = autor;

        this.Status = "Disponível";

    }

    public void Detalhes()
    {

        Console.WriteLine("\nNome: {0};", this.Nome);

        Console.WriteLine("Gênero: {0};", this.Genero);

        Console.WriteLine("Autor(a): {0};", this.Autor);

        Console.WriteLine("Status: {0}.", this.Status);

    }

    public Emprestimo? Alugar(string data_requisicao, Leitor requisitor)
    {

        if (this.Status == "Disponível")
        {

            Emprestimo emprestimo = new Emprestimo(data_requisicao, this, requisitor);

            requisitor.Livros_Alugados.Add(this);

            this.Status = "Alugado";

            return emprestimo;

        }

        else
        {

            return null;

        }

    }

    public void Devolver(Leitor requisitor)
    {

        if (this.Status == "Alugado")
        {

            if (requisitor.Livros_Alugados.Any(livro => livro.Nome == this.Nome))
            {

                requisitor.Livros_Alugados.Remove(this);

                this.Status = "Disponível";

            }

        }

    }

}

class Emprestimo
{

    public string? Data_Emprestimo { get; set; }

    public Livro? Livro { get; set; }

    public Leitor? Requisitor { get; set; }

    public Emprestimo(string data_emprestimo, Livro livro, Leitor requisitor)
    {

        this.Data_Emprestimo = data_emprestimo;

        this.Livro = livro;

        this.Requisitor = requisitor;

    }

    public void Detalhes()
    {

        Console.WriteLine("\nData de Empréstimo: {0};", this.Data_Emprestimo);

        Console.WriteLine("Livro Emprestado: {0};", this.Livro.Nome);

        Console.WriteLine("Requisitor(a): {0}.", this.Requisitor.Nome);

    }

}