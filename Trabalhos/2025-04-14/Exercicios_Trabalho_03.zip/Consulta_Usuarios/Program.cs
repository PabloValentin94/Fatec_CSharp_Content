﻿// Recursos Utilizados.

using System.IO;

// Execução.

try
{

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("LISTAGEM DE USUÁRIOS DO BANCO DE DADOS");

    Console.Write("---------------------------------------------------------------");

    Banco_Dados banco_dados = new Banco_Dados();

    Task registros = banco_dados.Obter_Registros();

    Task status_conexao = banco_dados.Verificar_Status_Conexao();

    await Task.WhenAll(registros, status_conexao);

}

catch (Exception ex)
{

    Console.Clear();

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine($"Saída: {ex.Message}");

}

finally
{

    Console.WriteLine("---------------------------------------------------------------");

    Console.ReadKey();

}

// Classes.

class Usuario
{

    private static int gerenciador_ids = 1;

    public int Id { get; set; }

    public string? Nome { get; set; }

    public Usuario(string nome)
    {

        this.Id = gerenciador_ids;

        this.Nome = nome;

        gerenciador_ids++;

    }

}

class Banco_Dados
{

    private bool status_conexao = false;

    private List<Usuario> registros = new List<Usuario>();

    public List<Usuario> Registros { get { return this.registros; } }

    public Banco_Dados()
    {

        string[] usuarios = {  };

        try
        {

            usuarios = File.ReadAllLines("../../../Dados.txt");

        }

        /*
         
            É recomendável adicionar essas exceções, pois elas retornam o caminho 
            especificado, sendo possível revisá-lo.

        */

        catch (DirectoryNotFoundException ex)
        {

            Console.WriteLine($"Repositório não encontrado!\n\nSaída: {ex.Message}");

        }

        catch (FileNotFoundException ex)
        {

            Console.WriteLine($"Arquivo não encontrado!\n\nSaída: {ex.Message}");

        }

        for (int quantidade_registros = 0; quantidade_registros < usuarios.Length; quantidade_registros++)
        {

            this.registros.Add(new Usuario(usuarios[quantidade_registros]));

        }

    }

    private void Abrir_Conexao()
    {

        this.status_conexao = true;

        Console.WriteLine("\nAbrindo uma conexão com o banco de dados.");

    }

    public async Task Verificar_Status_Conexao()
    {

        while (true)
        {

            if (!this.status_conexao)
            {

                break;

            }

            else
            {

                await Task.Delay(5000);

                Console.WriteLine("\nA conexão ainda está aberta.");

            }

        }

    }

    public async Task Obter_Registros()
    {

        this.Abrir_Conexao();

        foreach (Usuario usuario in this.Registros)
        {

            Console.WriteLine("\n- {0} ({1}).", usuario.Nome, usuario.Id);

            await Task.Delay(1000);

        }

        await this.Fechar_Conexao();

    }

    private async Task Fechar_Conexao()
    {

        this.status_conexao = false;

        await Task.Delay(6000);

        Console.WriteLine("\nFechando a conexão com o banco de dados.");

    }

}