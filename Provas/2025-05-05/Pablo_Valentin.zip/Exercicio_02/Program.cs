﻿// Execução.

try
{

    Console.WriteLine("-------------------------------------------------------------------------------------------------------------------");

    Console.Write("Insira seu nome: ");
    string? nome = Console.ReadLine();

    Console.Write("\nInsira sua idade: ");
    int idade = int.Parse(Console.ReadLine() ?? "0");

    if (String.IsNullOrWhiteSpace(nome))
    {

        throw new NullReferenceException("O nome passado não pode ser nulo, vazio ou composto só por espaços em branco.");

    }

    if (idade == 0)
    {

        throw new NotImplementedException("A idade não foi definida corretamente.");

    }

    if (idade < 0)
    {

        throw new ArgumentException("A idade passada não pode ser um número negativo.");

    }

}

catch (NullReferenceException ex)
{

    Limpar_Console();

    Console.WriteLine($"Erro!\n\nSaída (NullReferenceException): {ex.Message}");

}

catch (NotImplementedException ex)
{

    Limpar_Console();

    Console.WriteLine($"Erro!\n\nSaída (NotImplementedException): {ex.Message}");

}

catch (ArgumentException ex)
{

    Limpar_Console();

    Console.WriteLine($"Erro!\n\nSaída (ArgumentException): {ex.Message}");

}

catch (Exception ex)
{

    Limpar_Console();

    Console.WriteLine($"Erro genérico: {ex.Message}");

}

finally
{

    Console.WriteLine("-------------------------------------------------------------------------------------------------------------------");

    Console.ReadKey();

}

// Função.

static void Limpar_Console()
{

    Console.Clear();

    Console.WriteLine("-------------------------------------------------------------------------------------------------------------------");

}