﻿// Execução.

try
{

    Cliente cliente = new Cliente("Pablo Valentin", "123.456.789-10");

    Contratado contratado = new Contratado("Fun Enterprise", "123.456.789-10/001");

    cliente.Adicionar_Telefone(14, "12345-6789");

    contratado.Adicionar_Telefone(14, "4002-8922");

    Decoracao decoracao = new Decoracao("Temática Festa Junina");

    Festa festa = new Festa(DateTime.Now.ToString("dd/MM/yyyy"), "31/03/2025", 3000.50f, cliente, contratado, decoracao);

    festa.Exibir();

    await festa.Preparar_Async();

    await festa.Realizar_Async();

    await festa.Encerrar_Async();

}

catch (Exception ex)
{

    Console.Clear();

    Console.WriteLine("------------------------------------------------------------------------------------------");

    Console.WriteLine($"Erro: {ex.Message}");

}

finally
{

    Console.WriteLine("------------------------------------------------------------------------------------------");

    Console.ReadKey();

}

// Classes.

abstract class Pessoa
{

    // Para que o valor do atributo "Nome" possa ser exibido nos dados de uma festa, ele precisa ser público, pois a classe Festa não herda a classe Pessoa.

    public string? Nome { get; set; }

    protected List<Telefone> Telefones = new List<Telefone>();

    public Pessoa(string nome)
    {

        this.Nome = nome;

    }

    public void Adicionar_Telefone(int ddd, string numero)
    {

        this.Telefones.Add(new Telefone(ddd, numero));

    }

    internal class Telefone
    {

        public int DDD { get; set; }

        public string? Numero { get; set; }

        public Telefone(int ddd, string numero)
        {

            this.DDD = ddd;

            this.Numero = numero;

        }

    }

}

class Cliente : Pessoa
{

    public string? Cpf { get; set; }

    public Cliente(string nome, string cpf) : base(nome)
    {

        this.Cpf = cpf;

    }

}

class Contratado : Pessoa
{

    public string? Cnpj { get; set; }

    public List<Festa> Festas_Organizadas { get; set; } = new List<Festa>();

    public Contratado(string nome, string cnpj) : base(nome)
    {

        this.Cnpj = cnpj;

    }

}

class Decoracao
{

    public string? Descricao { get; set; }

    public Decoracao(string descricao)
    {

        this.Descricao = descricao;

    }

}

class Festa
{

    public string? Data_Festa { get; set; }

    public string? Data_Contrato { get; set; }

    public float Valor {  get; set; }

    public Cliente? Cliente { get; set; }

    public Contratado? Contratado { get; set; }

    public Decoracao? Decoracao { get; set; }

    public Festa(string data_festa, string data_contrato, float valor, Cliente cliente, Contratado contratado, Decoracao decoracao)
    {

        this.Data_Festa = data_festa;

        this.Data_Contrato = data_contrato;

        this.Valor = valor;

        this.Cliente = cliente;

        this.Contratado = contratado;

        this.Decoracao = decoracao;

        this.Contratado.Festas_Organizadas.Add(this);

    }

    public void Exibir()
    {

        Console.WriteLine("------------------------------------------------------------------------------------------");

        Console.WriteLine("DADOS DA FESTA");

        Console.WriteLine("------------------------------------------------------------------------------------------");

        Console.WriteLine("Data da Festa: {0};\n\nData de Contrato: {1};\n\nValor (Preço): {2};\n\nCliente: {3} ({4});\n\nEmpresa Contratada: {5} ({6});\n\nDecoração: {7}.",
                          this.Data_Festa, this.Data_Contrato, this.Valor.ToString("C2"), this.Cliente.Nome, this.Cliente.Cpf, this.Contratado.Nome, this.Contratado.Cnpj, this.Decoracao.Descricao);

    }

    public async Task Preparar_Async()
    {

        Console.WriteLine("------------------------------------------------------------------------------------------");

        Console.WriteLine("PREPARAÇÃO DA FESTA");

        Console.WriteLine("------------------------------------------------------------------------------------------");

        await Task.Delay(2000);

        Console.WriteLine("Preparando o local da festa...");

        await Task.Delay(2000);

        Console.WriteLine("\nPreparando os alimentos da festa...");

        await Task.Delay(2000);

        Console.WriteLine("\nPreparando os funcionários da festa...");

        await Task.Delay(2000);

        Console.WriteLine("\nPreparação concluída.");

    }

    public async Task Realizar_Async()
    {

        Console.WriteLine("------------------------------------------------------------------------------------------");

        Console.WriteLine("REALIZAÇÃO DA FESTA");

        Console.WriteLine("------------------------------------------------------------------------------------------");

        await Task.Delay(2000);

        Console.WriteLine("Iniciando a festa...");

        await Task.Delay(2000);

        Console.WriteLine("\nA festa está acontecendo...");

        await Task.Delay(2000);

        Console.WriteLine("\nA festa ainda está acontecendo...");

        await Task.Delay(2000);

        Console.WriteLine("\nA festa acabou.");

    }

    public async Task Encerrar_Async()
    {

        Console.WriteLine("------------------------------------------------------------------------------------------");

        Console.WriteLine("ENCERRAMENTO DA FESTA");

        Console.WriteLine("------------------------------------------------------------------------------------------");

        await Task.Delay(2000);

        Console.WriteLine("Limpando o local da festa...");

        await Task.Delay(2000);

        Console.WriteLine("\nRecolhendo os alimentos restantes da festa...");

        await Task.Delay(2000);

        Console.WriteLine("\nLiberando os funcionários da festa...");

        await Task.Delay(2000);

        Console.WriteLine("\nEncerramento concluído.");

    }

}