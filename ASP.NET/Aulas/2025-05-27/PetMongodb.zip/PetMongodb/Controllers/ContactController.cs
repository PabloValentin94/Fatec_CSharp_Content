﻿using Microsoft.AspNetCore.Mvc;

using PetMongodb.Services;

using PetMongodb.Repositories;

using Microsoft.AspNetCore.Identity;

using PetMongodb.Models;

using PetMongodb.ViewModels;

namespace PetMongodb.Controllers
{

    public class ContactController : Controller
    {

        private readonly EmailService _email_service;

        private readonly IPetRepository _pet_repository;

        private readonly UserManager<ApplicationUser> _user_manager;

        public ContactController(EmailService email_service, IPetRepository pet_repository, UserManager<ApplicationUser> user_manager)
        {

            this._email_service = email_service;

            this._pet_repository = pet_repository;

            this._user_manager = user_manager;

        }

        public async Task<IActionResult> SendEmail(Guid pet_id)
        {

            Pet pet = await this._pet_repository.Get_By_Id(pet_id);

            if (pet == null || String.IsNullOrEmpty(pet.IdUsuario))
            {

                return NotFound();

            }

            ApplicationUser tutor = await this._user_manager.FindByIdAsync(pet.IdUsuario);

            if (tutor == null)
            {

                return NotFound();

            }

            ContactViewModel template_email = new ContactViewModel()
            {

                Pet_Id = pet.Id,

                Tutor = tutor.NomeCompleto,

                Endereco_Email = tutor.Email,

                Pet = pet.Nome

            };

            return View(template_email);

        }

        [HttpPost]
        public async Task<IActionResult> SendEmail(string nome_pet, string tutor, string endereco_email, string mensagem)
        {

            string assunto_email = "Teste de envio de e-mail.";

            string corpo_email = $@"
                    <!DOCTYPE html>
                    <html>
                        <head>
                            <meta charset=""utf-8""/>
                        </head>
                        <body>
                            <p> <strong> Nome: </strong> {tutor} </p>
                            <p> <strong> Nome: </strong> {endereco_email} </p>
                            <p> <strong> Mensagem: </strong> {mensagem} </p>
                        </body>
                    </html>
                ";

            await this._email_service.SendAsync(endereco_email, assunto_email, corpo_email);

            ViewBag.Message = "E-mail enviado com sucesso!";

            return View(new ContactViewModel());

        }

    }

}