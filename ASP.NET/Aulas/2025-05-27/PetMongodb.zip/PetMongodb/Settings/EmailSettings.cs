﻿namespace PetMongodb.Settings
{

    public class EmailSettings
    {



    }

}