﻿using AspNetCore.Identity.MongoDbCore.Models;
using MongoDbGenericRepository.Attributes;

namespace PetMongodb.Models
{
    [CollectionName("User")]
    public class ApplicationUser:MongoIdentityUser
    {
        // Os campos especificados aqui, além dos da classe pai, serão aqueles salvos no MongoDB.

        public string? NomeCompleto { get; set; }
    }
}
