﻿namespace PetMongodb.ViewModels
{

    public class ContactViewModel
    {

        public Guid Pet_Id { get; set; }

        public string? Pet { get; set; }

        public string? Tutor { get; set; }

        public string? Endereco_Email { get; set; }

    }

}