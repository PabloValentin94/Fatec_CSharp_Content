﻿using Microsoft.Extensions.Options;

using System.Net.Mail;

using MimeKit;

using MimeKit.Text;

using PetMongodb.Settings;

namespace PetMongodb.Services
{

    public class EmailService
    {

        private readonly IOptions<EmailSettings> _email_settings;

        public EmailService(IOptions<EmailSettings> email_settings)
        {

            this._email_settings = email_settings;

        }

        public async Task SendAsync(string endereco_email, string assunto, string mensagem)
        {

            MimeMessage email = new MimeMessage();

            email.From.Add(new MailboxAddress(this._email_settings.SenderName, this._email_settings.SenderEmail));

            email.To.Add(MailboxAddress.Parse(endereco_email));

            email.Subject = assunto;

            email.Body = new TextPart(TextFormat.Html)
            {

                Text = mensagem

            };

            using(SmtpClient smtp = new SmtpClient())
            {

                await smtp.ConnectAsync(this._email_settings.SmtpServer, this._email_settings.SmtpPort, MailKit.Security.SecureSocketOptions.StartTls);

                await smtp.AuthenticateAsync(this._email_settings.UserName, this._email_settings.Password);

                await smtp.SendAsync(email);

                await smtp.DisconnectAsync(true);

            }

        }

    }

}