﻿using PetMongodb.Models;

using MongoDB.Driver;

namespace PetMongodb.Repositories
{

    public class PetRepository : IPetRepository
    {

        private readonly ContextMongodb _context;

        public PetRepository()
        {

            this._context = new ContextMongodb();

        }

        public async Task<Pet> Get_By_Id(Guid id)
        {

            return await this._context.Pet.Find(p => p.Id == id).FirstOrDefaultAsync();

        }

    }

}