﻿using PetMongodb.Models;

namespace PetMongodb.Repositories
{

    public interface IPetRepository
    {

        public Task<Pet> Get_By_Id(Guid id);

    }

}