﻿using System.ComponentModel.DataAnnotations;

namespace PetMongodb.Models
{
    public class Pet
    {
        public Guid Id { get; set; }

        public string? Nome { get; set; }

        public string? Idade { get; set; }

        public string? Raca { get; set; }

        [Required]
        [Display(Name = "Cor Predominante")]
        public string? CorPredominante { get; set; }

        [Required]
        [Display(Name = "Cor dos Olhos")]
        public string? CorOlhos { get; set; }

        [Required]
        [Display(Name = "Espécie")]
        public string? Especie { get; set; }

        [Required]
        [Display(Name = "Gênero")]
        public string? Genero { get; set; }

        public string? Porte { get; set; }

        [Required]
        public string? Local { get; set; }

        [Required]
        [Display(Name = "Ponto de Referência")]
        public string? PontoReferencia { get; set; }

        [Required]
        public DateOnly? Data { get; set; }

        public decimal Recompensa { get; set; }

        public string? IdUsuario { get; set; }

        [Required]
        [Display(Name = "Situação")]
        public string? Situacao { get; set; } 

        public string? Imagem { get; set; }

        [Display(Name = "Comentário")]
        public string? Comentario { get; set; }
    }
}
