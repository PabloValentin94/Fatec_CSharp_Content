﻿using Conceitos_ASP_NET_Core_MVC.Models;

using Microsoft.EntityFrameworkCore;

namespace Conceitos_ASP_NET_Core_MVC.Data
{

    public class Application_DB_Context : DbContext
    {

        public Application_DB_Context(DbContextOptions<Application_DB_Context> options) : base(options) {  }

        public DbSet<Usuario> usuarios { get; set; }

        public DbSet<Aluno> alunos { get; set; }

        public DbSet<Curso> cursos { get; set; }

        public DbSet<Disciplina> disciplinas { get; set; }

        public DbSet<Matricula> matriculas { get; set; }

    }

}