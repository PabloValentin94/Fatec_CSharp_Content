﻿namespace Conceitos_ASP_NET_Core_MVC.Models
{

    public class Curso
    {

        public int id { get; set; }

        public string? nome { get; set; }

        public int vagas { get; set; }

        public List<Disciplina>? disciplinas { get; set; }

    }

}