﻿namespace Conceitos_ASP_NET_Core_MVC.Models
{

    public class Disciplina
    {

        public int id { get; set; }

        public string? nome { get; set; }

        public int semestre { get; set; }

        public int fk_curso { get; set; }

        public Curso? curso { get; set; }

    }

}