﻿namespace Conceitos_ASP_NET_Core_MVC.Models
{

    public class Matricula
    {

        public int id { get; set; }

        public DateTime data_matricula { get; set; }

        public int fk_aluno { get; set; }

        public int fk_curso { get; set; }

    }

}