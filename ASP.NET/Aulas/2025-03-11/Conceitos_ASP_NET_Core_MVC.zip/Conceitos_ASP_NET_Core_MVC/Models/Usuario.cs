﻿namespace Conceitos_ASP_NET_Core_MVC.Models
{

    public class Usuario
    {

        public int id { get; set; }

        public string? nome { get; set; }

        public string? email { get; set; }

        public string? senha { get; set; }

    }

}