﻿namespace Conceitos_ASP_NET_Core_MVC.Models
{
    public class Aluno
    {

        public int id { get; set; }

        public string? ra { get; set; }

        public int fk_usuario { get; set; }
        public Usuario? Usuario { get; set; }

    }

}