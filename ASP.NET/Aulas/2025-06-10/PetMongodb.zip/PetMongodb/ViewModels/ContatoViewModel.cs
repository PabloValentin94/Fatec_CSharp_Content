﻿namespace PetMongodb.Models
{
    public class ContatoViewModel
    {
        public Guid? PetId { get; set; }
        public string? NomePet { get; set; }
        public string? NomeTutor { get; set; }
        public string? EmailTutor { get; set; }
        public string? Mensagem { get; set; }
    }
}
