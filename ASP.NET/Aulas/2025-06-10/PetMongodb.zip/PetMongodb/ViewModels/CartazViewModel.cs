﻿namespace PetMongodb.ViewModels
{

    public class CartazViewModel
    {

        public string? TItulo { get; set; }

        public string? Descricao { get; set; }

        public string? Caracteristicas { get; set; }

        public string? Url_Foto { get; set; }

        public string? Contato { get; set; }

        public string? Celular { get; set; }

        public string? Email { get; set; }

    }
}