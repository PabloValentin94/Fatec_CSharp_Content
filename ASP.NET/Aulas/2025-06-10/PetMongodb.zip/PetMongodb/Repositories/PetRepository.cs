﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using PetMongodb.Models;
using System.Drawing;

namespace PetMongodb.Repositories
{
    public class PetRepository: IPetRepository
    {
        private readonly ContextMongodb _context = new ContextMongodb();
        public Pet GetById(Guid id)
        {
            return  _context.Pet.Find(p => p.Id == id).FirstOrDefault();
            
        }

       
    }
}

