﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Serializers;

using MongoDB.Driver;

namespace Conexao_MongoDB.Models
{

    public class Context_MongoDB
    {

        // Atributos.

        public static string? connection_string { get; set; }

        public static string? database_name { get; set; }

        public static bool is_ssl { get; set; }

        private IMongoDatabase database { get; } // Somente leitura.

        // Construtores.

        static Context_MongoDB()
        {

            BsonSerializer.RegisterSerializer(new GuidSerializer(GuidRepresentation.Standard));

        }

        public Context_MongoDB()
        {

            try
            {

                MongoClientSettings settings = MongoClientSettings.FromUrl(new MongoUrl(connection_string));

                if (is_ssl)
                {

                    settings.SslSettings = new SslSettings { EnabledSslProtocols = System.Security.Authentication.SslProtocols.Tls12 };

                }

                MongoClient mongo_cliente = new MongoClient(settings);

                database = mongo_cliente.GetDatabase(database_name);

            }

            catch(Exception ex)
            {

                throw new Exception("Não foi possível estabelecer uma conexão com o MongoDB.");

            }

        }

        // Coleções (Collections).

        public IMongoCollection<Pet> pets { get { return database.GetCollection<Pet>("pets"); } }

    }

}