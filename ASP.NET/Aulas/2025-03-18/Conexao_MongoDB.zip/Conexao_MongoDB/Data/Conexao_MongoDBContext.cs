﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Conexao_MongoDB.Models;

namespace Conexao_MongoDB.Data
{
    public class Conexao_MongoDBContext : DbContext
    {
        public Conexao_MongoDBContext (DbContextOptions<Conexao_MongoDBContext> options)
            : base(options)
        {
        }

        public DbSet<Conexao_MongoDB.Models.Pet> Pet { get; set; } = default!;
    }
}
