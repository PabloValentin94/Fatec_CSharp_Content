﻿using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Identity;

using Conexao_MongoDB.Models;

using System.ComponentModel.DataAnnotations;

namespace Conexao_MongoDB.Controllers
{
    public class AccountController : Controller
    {
        private UserManager<Application_User>? user_manager;

        private SignInManager<Application_User>? sign_in_manager;

        public AccountController(UserManager<Application_User> user_manager, SignInManager<Application_User> sign_in_manager)
        {
            this.user_manager = user_manager;

            this.sign_in_manager = sign_in_manager;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login([Required, EmailAddress(ErrorMessage = "E-mail inválido!")] string email, [Required] string senha)
        {
            if (ModelState.IsValid)
            {
                Application_User? usuario = await user_manager.FindByEmailAsync(email);

                if (usuario != null)
                {
                    Microsoft.AspNetCore.Identity.SignInResult resultado_login = await sign_in_manager.PasswordSignInAsync(usuario, senha, false, false);

                    if(resultado_login.Succeeded)
                    {
                        return RedirectToAction("Index", "Home");
                    }

                    else
                    {
                        ModelState.AddModelError(nameof(email), "Erro ao efetuar o login! Verifique seus dados.");
                    }
                }
            }

            return View();
        }

        public async Task<IActionResult> Logout()
        {
            await sign_in_manager.SignOutAsync();

            return RedirectToAction("Index", "Home");
        }
    }
}
