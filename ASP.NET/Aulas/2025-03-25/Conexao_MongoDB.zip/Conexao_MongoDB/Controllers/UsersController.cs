﻿using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Identity;

using Conexao_MongoDB.Models;

namespace Conexao_MongoDB.Controllers
{
    public class UsersController : Controller
    {
        private UserManager<Application_User>? user_manager;

        // private RoleManager<Application_Roles>? role_manager;

        public UsersController(UserManager<Application_User> user_manager, RoleManager<Application_Role> role_manager)
        {
            this.user_manager = user_manager;

            // this.role_manager = role_manager;
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(User model_usuario)
        {
            if (ModelState.IsValid)
            {
                Application_User? usuario = new Application_User();

                usuario.UserName = model_usuario.nome;

                usuario.Email = model_usuario.email;

                IdentityResult resultado_cadastro_usuario = await this.user_manager.CreateAsync(usuario, model_usuario.senha);

                if (resultado_cadastro_usuario.Succeeded)
                {
                    ViewBag.Message = "Usuário cadastrado com sucesso.";
                }

                else
                {
                    foreach (IdentityError erro in resultado_cadastro_usuario.Errors)
                    {
                        ModelState.AddModelError("", erro.Description);
                    }
                }
            }

            return View(model_usuario);
        }
    }
}
