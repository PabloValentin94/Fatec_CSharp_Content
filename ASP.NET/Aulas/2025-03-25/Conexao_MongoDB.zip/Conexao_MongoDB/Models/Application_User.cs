﻿using AspNetCore.Identity.MongoDbCore.Models;

using MongoDbGenericRepository.Attributes;

namespace Conexao_MongoDB.Models
{

    [CollectionName("User")]
    public class Application_User : MongoIdentityUser
    {



    }

}