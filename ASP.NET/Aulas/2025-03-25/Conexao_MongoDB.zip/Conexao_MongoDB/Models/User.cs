﻿using System.ComponentModel.DataAnnotations;

namespace Conexao_MongoDB.Models
{

    public class User
    {

        [Required]
        public string? nome { get; set; }

        [Required]
        public string? celular { get; set; }

        [Required, EmailAddress(ErrorMessage = "E-mail inválido!")]
        public string? email { get; set; }

        [Required]
        public string? senha { get; set; }

    }

}