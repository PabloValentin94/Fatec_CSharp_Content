﻿using AspNetCore.Identity.MongoDbCore.Models;

using MongoDbGenericRepository.Attributes;

namespace Conexao_MongoDB.Models
{

    [CollectionName("Role")]
    public class Application_Role : MongoIdentityRole
    {



    }

}