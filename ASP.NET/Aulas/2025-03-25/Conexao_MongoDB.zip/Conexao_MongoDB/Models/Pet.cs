﻿namespace Conexao_MongoDB.Models
{

    public class Pet
    {

        public Guid id { get; set; }

        public string? nome { get; set; }

        public int idade { get; set; }

        public string? raca { get; set; }

        public string? cuidador { get; set; }

        public string? celular { get; set; }

    }

}