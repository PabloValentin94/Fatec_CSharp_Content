﻿using Conexao_MongoDB.Models;

using Microsoft.EntityFrameworkCore;

using Conexao_MongoDB.Data;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<Conexao_MongoDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Conexao_MongoDBContext") ?? throw new InvalidOperationException("Connection string 'Conexao_MongoDBContext' not found.")));

// Add services to the container.
builder.Services.AddControllersWithViews();

// Configurações - MongoDB.

Context_MongoDB.connection_string = builder.Configuration.GetSection("MongoConnection:ConnectionString").Value;

Context_MongoDB.database_name = builder.Configuration.GetSection("MongoConnection:Database").Value;

Context_MongoDB.is_ssl = Convert.ToBoolean(builder.Configuration.GetSection("MongoConnection:IsSSL").Value);

// Configurações - Identity.

builder.Services.AddIdentity<Application_User, Application_Role>().AddMongoDbStores<Application_User, Application_Role, Guid>(Context_MongoDB.connection_string, Context_MongoDB.database_name);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
