﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PetMongodb.Models;

using System.Text.RegularExpressions;

namespace PetMongodb.Controllers
{
    public class UserController : Controller
    {
        private UserManager<ApplicationUser> _userManager;

        private RoleManager<ApplicationRole> _roleManager;

        public UserController(UserManager<ApplicationUser> userManager,RoleManager<ApplicationRole> roleManager)
        {
            this._userManager = userManager;

            this._roleManager = roleManager;
        }

        public IActionResult Create(string? role)
        {
            ViewBag.Role = role;

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(User user, string role)
        {
            if(ModelState.IsValid)
            {
                ApplicationUser app_user = new ApplicationUser();

                // Aprofundamento: https://gist.github.com/PabloValentin94/67343c258863eb1d157b881bf5adb074

                app_user.UserName = Regex.Replace(Models.User.Remover_Acentos(user.NomeCompleto), @"[^a-zA-Z0-9]", "");

                app_user.NomeCompleto = user.NomeCompleto;

                app_user.Email = user.Email;

                IdentityResult result = await _userManager.CreateAsync(app_user, user.Password);

                if(result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(app_user, role);

                    ViewBag.Message = "Usuário Cadastrado com sucesso.";
                }
                else
                {
                    foreach(IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }

            return View();
        }

        [Authorize(Roles = "Administrador")]
        public IActionResult CreateRole()
        {
            return View();
        }

        [Authorize(Roles = "Administrador")]
        [HttpPost]
        public async Task<IActionResult> CreateRole(Role role)
        {
            if (ModelState.IsValid)
            {
                IdentityResult result = await _roleManager.CreateAsync(new ApplicationRole()
                {
                    Name = role.Nome
                });

                if (result.Succeeded)
                {
                    ViewBag.Message = "Cargo cadastrado com sucesso.";
                }

                else
                {
                    foreach (IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }

            return View();
        }
    }
}
