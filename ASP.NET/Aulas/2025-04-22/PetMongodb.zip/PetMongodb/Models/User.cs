﻿using System.ComponentModel.DataAnnotations;

using System.Globalization;
using System.Text;

namespace PetMongodb.Models
{
    public class User
    {
        [Required]
        [Display(Name = "Nome Completo")]
        public string? NomeCompleto { get; set; }

        [Required]
        public string? Celular { get; set; }

        [Required]
        [EmailAddress(ErrorMessage="E-mail inválido")]
        public string? Email { get; set; }

        [Required]
        public string? Password { get; set; }

        // Aprofundamento: https://gist.github.com/PabloValentin94/67343c258863eb1d157b881bf5adb074

        public static string Remover_Acentos(string texto_acentos)
        {
            string texto_simbolos_letras_separados = texto_acentos.Normalize(NormalizationForm.FormD);

            StringBuilder string_retorno = new StringBuilder();

            foreach (char caractere in texto_simbolos_letras_separados)
            {

                if (CharUnicodeInfo.GetUnicodeCategory(caractere) != UnicodeCategory.NonSpacingMark)
                {

                    string_retorno.Append(caractere);

                }

            }

            return string_retorno.ToString().Normalize(NormalizationForm.FormC);
        }
    }
}
