﻿using System.ComponentModel.DataAnnotations;

namespace PetMongodb.Models
{
    public class Role
    {
        [Required]
        public string? Nome { get; set; }
    }
}
