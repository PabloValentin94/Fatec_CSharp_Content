﻿using PetMongodb.Models;

namespace PetMongodb.Repositories
{
    public interface IPetRepository
    {
        Pet GetById(Guid id);
    }
}
