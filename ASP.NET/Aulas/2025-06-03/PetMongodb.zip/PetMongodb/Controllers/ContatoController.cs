﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PetMongodb.Models;
using PetMongodb.Repositories;
using PetMongodb.Services;

namespace PetMongodb.Controllers
{
    public class ContatoController : Controller
    {
        private readonly EmailService _emailService;
        private readonly IPetRepository _petRepo;
        private readonly UserManager<ApplicationUser> _userManager;

        public ContatoController(IPetRepository petRepo, UserManager<ApplicationUser> userManager, EmailService emailService)
        {
            _petRepo = petRepo;
            _userManager = userManager;
            _emailService = emailService;
        }




        [HttpGet]
        public async Task<IActionResult> Enviar(Guid petId)
        {

            var pet =  _petRepo.GetById(petId);
            Console.WriteLine(pet);
            if (pet == null || string.IsNullOrEmpty(pet.IdUsuario))
                return NotFound();

            var tutor = await _userManager.FindByIdAsync(pet.IdUsuario);

            if (tutor == null)
                return NotFound();
            var modelo = new ContatoViewModel
            {
                PetId = pet.Id,
                NomeTutor = tutor.NomeCompleto,
                EmailTutor = tutor.Email,
                NomePet = pet.Nome
            };

            return View(modelo);
        }

        
        [HttpPost]
        public async Task<IActionResult> Enviar(string nomePet, string emailTutor, string nomeTutor, string mensagem)
        {
            
            var assunto = "Mensagem do site meu pet sumiu";
            var corpo = $@"
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset=""utf-8"">
            </head>
            <body>
                <p><strong>Nome:</strong> {nomeTutor}</p>
                <p><strong>Email:</strong> {emailTutor}</p>
                <pre><strong>Mensagem:</strong> {mensagem}</pre>
            </body>
            </html>";

            
            Console.WriteLine(corpo);
            await _emailService.SendEmailAsync("vania@fgp.com.br", assunto, corpo);
            ViewBag.Mensagem = "Email enviado com sucesso!";
            return View(new ContatoViewModel());
        }

    }
}
