﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PetMongodb.Models;

using System.Text.RegularExpressions;

namespace PetMongodb.Controllers
{
    public class UserController : Controller
    {
        private UserManager<ApplicationUser> _userManager;

        public UserController(UserManager<ApplicationUser> userManager,RoleManager<ApplicationRole> roleManager)
        {
            this._userManager = userManager;
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(User user)
        {
            if(ModelState.IsValid)
            {
                ApplicationUser appuser = new ApplicationUser();

                // Aprofundamento: https://gist.github.com/PabloValentin94/67343c258863eb1d157b881bf5adb074

                appuser.UserName = Regex.Replace(Models.User.Remover_Acentos(user.NomeCompleto), @"[^a-zA-Z0-9]", "");

                appuser.NomeCompleto = user.NomeCompleto;

                appuser.Email = user.Email;

                IdentityResult result = await _userManager.CreateAsync(appuser, user.Password);
                if(result.Succeeded)
                {
                    ViewBag.Message = "Usuário Cadastrado com sucesso";
                }
                else
                {
                    foreach(IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            return View();
        }
    }
}
