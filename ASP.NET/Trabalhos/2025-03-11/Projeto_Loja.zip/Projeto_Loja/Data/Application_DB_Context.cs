﻿using Microsoft.EntityFrameworkCore;

using Projeto_Loja.Models;

namespace Projeto_Loja.Data
{

    public class Application_DB_Context : DbContext
    {

        public Application_DB_Context(DbContextOptions<Application_DB_Context> options) : base(options) {  }

        public DbSet<Usuario> usuarios { get; set; }

        public DbSet<Compra> compras { get; set; }

        public DbSet<Categoria> categorias { get; set; }

        public DbSet<Itens> itens { get; set; }

        public DbSet<Produto> produtos { get; set; }

        public DbSet<Produto_Categoria> produto_categoria { get; set; }

    }

}