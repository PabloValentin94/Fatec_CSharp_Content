﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Projeto_Loja.Data;
using Projeto_Loja.Models;

namespace Projeto_Loja.Controllers
{
    public class ItensController : Controller
    {
        private readonly Application_DB_Context _context;

        public ItensController(Application_DB_Context context)
        {
            _context = context;
        }

        // GET: Itens
        public async Task<IActionResult> Index()
        {
            return View(await _context.itens.ToListAsync());
        }

        // GET: Itens/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var itens = await _context.itens
                .FirstOrDefaultAsync(m => m.id == id);
            if (itens == null)
            {
                return NotFound();
            }

            return View(itens);
        }

        // GET: Itens/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Itens/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id,quantidade,fk_compra,fk_produto")] Itens itens)
        {
            if (ModelState.IsValid)
            {
                _context.Add(itens);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(itens);
        }

        // GET: Itens/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var itens = await _context.itens.FindAsync(id);
            if (itens == null)
            {
                return NotFound();
            }
            return View(itens);
        }

        // POST: Itens/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,quantidade,fk_compra,fk_produto")] Itens itens)
        {
            if (id != itens.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(itens);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ItensExists(itens.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(itens);
        }

        // GET: Itens/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var itens = await _context.itens
                .FirstOrDefaultAsync(m => m.id == id);
            if (itens == null)
            {
                return NotFound();
            }

            return View(itens);
        }

        // POST: Itens/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var itens = await _context.itens.FindAsync(id);
            if (itens != null)
            {
                _context.itens.Remove(itens);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ItensExists(int id)
        {
            return _context.itens.Any(e => e.id == id);
        }
    }
}
