﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Projeto_Loja.Data;
using Projeto_Loja.Models;

namespace Projeto_Loja.Controllers
{
    public class ProdutoCategoriaController : Controller
    {
        private readonly Application_DB_Context _context;

        public ProdutoCategoriaController(Application_DB_Context context)
        {
            _context = context;
        }

        // GET: ProdutoCategoria
        public async Task<IActionResult> Index()
        {
            return View(await _context.produto_categoria.ToListAsync());
        }

        // GET: ProdutoCategoria/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var produto_Categoria = await _context.produto_categoria
                .FirstOrDefaultAsync(m => m.id == id);
            if (produto_Categoria == null)
            {
                return NotFound();
            }

            return View(produto_Categoria);
        }

        // GET: ProdutoCategoria/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ProdutoCategoria/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id,fk_produto,fk_categoria")] Produto_Categoria produto_Categoria)
        {
            if (ModelState.IsValid)
            {
                _context.Add(produto_Categoria);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(produto_Categoria);
        }

        // GET: ProdutoCategoria/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var produto_Categoria = await _context.produto_categoria.FindAsync(id);
            if (produto_Categoria == null)
            {
                return NotFound();
            }
            return View(produto_Categoria);
        }

        // POST: ProdutoCategoria/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,fk_produto,fk_categoria")] Produto_Categoria produto_Categoria)
        {
            if (id != produto_Categoria.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(produto_Categoria);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!Produto_CategoriaExists(produto_Categoria.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(produto_Categoria);
        }

        // GET: ProdutoCategoria/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var produto_Categoria = await _context.produto_categoria
                .FirstOrDefaultAsync(m => m.id == id);
            if (produto_Categoria == null)
            {
                return NotFound();
            }

            return View(produto_Categoria);
        }

        // POST: ProdutoCategoria/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var produto_Categoria = await _context.produto_categoria.FindAsync(id);
            if (produto_Categoria != null)
            {
                _context.produto_categoria.Remove(produto_Categoria);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool Produto_CategoriaExists(int id)
        {
            return _context.produto_categoria.Any(e => e.id == id);
        }
    }
}
