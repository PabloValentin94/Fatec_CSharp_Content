﻿namespace Projeto_Loja.Models
{

    public class Produto
    {

        public int id { get; set; }

        public string? nome { get; set; }

        public string? descricao { get; set; }

        public double preco { get; set; }

        public List<Produto_Categoria>? categorias { get; set; }

    }

}