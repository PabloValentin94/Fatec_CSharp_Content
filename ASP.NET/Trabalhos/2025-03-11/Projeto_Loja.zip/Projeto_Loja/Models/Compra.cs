﻿namespace Projeto_Loja.Models
{

    public class Compra
    {

        public int id { get; set; }

        public DateTime data_compra { get; set; }

        public int fk_usuario { get; set; }

        public Usuario? usuario { get; set; }

        public List<Itens>? itens { get; set; }

    }

}