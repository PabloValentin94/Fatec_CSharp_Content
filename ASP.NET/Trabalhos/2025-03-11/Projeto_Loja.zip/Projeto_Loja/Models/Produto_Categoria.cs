﻿namespace Projeto_Loja.Models
{

    public class Produto_Categoria
    {

        public int id { get; set; }

        public int fk_produto { get; set; }

        public int fk_categoria { get; set; }

        public Produto? produto { get; set; }

        public Categoria? categoria { get; set; }

    }

}