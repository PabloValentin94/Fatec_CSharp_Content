﻿namespace Projeto_Loja.Models
{

    public class Categoria
    {

        public int id { get; set; }

        public string? descricao { get; set; }

    }

}