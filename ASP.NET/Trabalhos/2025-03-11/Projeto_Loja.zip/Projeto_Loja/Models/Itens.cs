﻿namespace Projeto_Loja.Models
{

    public class Itens
    {

        public int id { get; set; }

        public int quantidade { get; set; }

        public int fk_compra { get; set; }

        public int fk_produto { get; set; }

        public Compra? compra { get; set; }

        public Produto? produto { get; set; }

    }

}