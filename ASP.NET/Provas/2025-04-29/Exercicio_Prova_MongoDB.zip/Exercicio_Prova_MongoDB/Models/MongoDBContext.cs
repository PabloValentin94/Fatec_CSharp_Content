﻿using MongoDB.Driver;

namespace Exercicio_Prova_MongoDB.Models
{
    public class MongoDBContext
    {
        public static string? Connection_String { get; set; }

        public static string? Database_Name { get; set; }

        public static bool Is_Ssl { get; set; }

        private IMongoDatabase? Database { get; set; }

        public MongoDBContext()
        {
            try
            {
                MongoClientSettings configuracoes_conexao = MongoClientSettings.FromUrl(new MongoUrl(Connection_String));

                if (Is_Ssl)
                {
                    configuracoes_conexao.SslSettings = new SslSettings()
                    {
                        EnabledSslProtocols = System.Security.Authentication.SslProtocols.Tls12
                    };
                }

                MongoClient utilizados_conexao = new MongoClient(configuracoes_conexao);

                this.Database = utilizados_conexao.GetDatabase(Database_Name);
            }

            catch (Exception ex)
            {
                throw new Exception($"Não foi possível se conectar ao MongoDB!\n\nSaída: {ex.Message}");
            }
        }

        public IMongoCollection<Casa>? Casas { get { return this.Database.GetCollection<Casa>("Casa"); } }
    }
}
