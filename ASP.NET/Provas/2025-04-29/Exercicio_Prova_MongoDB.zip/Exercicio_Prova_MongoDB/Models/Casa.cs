﻿namespace Exercicio_Prova_MongoDB.Models
{
    public class Casa
    {
        private Guid _id;

        public Guid Id { get { return this._id; } set { this._id = value; } }

        public string? Nome { get; set; }

        public string? Luz_Sala { get; set; } = "Apagada";

        public string? Luz_Quarto { get; set; } = "Apagada";

        public string? Luz_Banheiro { get; set; } = "Apagada";
    }
}
