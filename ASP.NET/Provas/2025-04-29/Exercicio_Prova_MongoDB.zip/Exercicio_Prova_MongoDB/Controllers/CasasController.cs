﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Exercicio_Prova_MongoDB.Models;

using MongoDB.Driver;

namespace Exercicio_Prova_MongoDB.Controllers
{
    public class CasasController : Controller
    {
        private readonly MongoDBContext _context;

        public CasasController()
        {
            _context = new MongoDBContext();
        }

        // GET: Casas
        public async Task<IActionResult> Index()
        {
            return View(await _context.Casas.Find(casa => casa.Id != null).ToListAsync());
        }

        // GET: Casas/Lampadas
        public async Task<IActionResult> Lampadas(string situacao_lampadas)
        {
            ViewBag.Situacao_Lampadas = situacao_lampadas;

            return View(await _context.Casas.Find(casa => casa.Id != null).ToListAsync());
        }

        // POST: Casas/Lampadas/5
        [HttpPost]
        public async Task<IActionResult> Lampadas(Guid? id, string situacao_lampadas)
        {
            var casa = await _context.Casas.Find(casa => casa.Id == id).FirstOrDefaultAsync();

            if (situacao_lampadas == "Acender")
            {

                casa.Luz_Sala = "Acesa";

                casa.Luz_Quarto = "Acesa";

                casa.Luz_Banheiro = "Acesa";

            }

            else
            {

                casa.Luz_Sala = "Apagada";

                casa.Luz_Quarto = "Apagada";

                casa.Luz_Banheiro = "Apagada";

            }

            await _context.Casas.ReplaceOneAsync(c => c.Id == id, casa);

            return RedirectToAction(nameof(Index));
        }

        // GET: Casas/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var casa = await _context.Casas.Find(casa => casa.Id == id).FirstOrDefaultAsync();

            if (casa == null)
            {
                return NotFound();
            }

            return View(casa);
        }

        // GET: Casas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Casas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nome")] Casa casa)
        {
            if (ModelState.IsValid)
            {
                casa.Id = Guid.NewGuid();

                await _context.Casas.InsertOneAsync(casa);

                return RedirectToAction(nameof(Index));
            }

            return View(casa);
        }

        // GET: Casas/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var casa = await _context.Casas.Find(casa => casa.Id == id).FirstOrDefaultAsync();

            if (casa == null)
            {
                return NotFound();
            }

            return View(casa);
        }

        // POST: Casas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,Nome,Luz_Sala,Luz_Quarto,Luz_Banheiro")] Casa casa)
        {
            if (id != casa.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _context.Casas.ReplaceOneAsync(c => c.Id == id, casa);
                }

                catch (DbUpdateConcurrencyException)
                {
                    if (!CasaExists(casa.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(casa);
        }

        // GET: Casas/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var casa = await _context.Casas.Find(casa => casa.Id == id).FirstOrDefaultAsync();

            if (casa == null)
            {
                return NotFound();
            }

            return View(casa);
        }

        // POST: Casas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            await _context.Casas.DeleteOneAsync(casa => casa.Id == id);

            return RedirectToAction(nameof(Index));
        }

        private bool CasaExists(Guid id)
        {
            return _context.Casas.Find(casa => casa.Id != null).Any();
        }
    }
}
