﻿using Microsoft.EntityFrameworkCore;

using Exercicio_Prova_MongoDB.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<PseudoMongoDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("PseudoMongoDBContext") ?? throw new InvalidOperationException("Connection string 'PseudoMongoDBContext' not found.")));

// Add services to the container.
builder.Services.AddControllersWithViews();

MongoDBContext.Connection_String = builder.Configuration.GetSection("MongoDBConnection:ConnectionString").Value;

MongoDBContext.Database_Name = builder.Configuration.GetSection("MongoDBConnection:DatabaseName").Value;

MongoDBContext.Is_Ssl = Convert.ToBoolean(builder.Configuration.GetSection("MongoDBConnection:IsSsl").Value);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Casas}/{action=Index}");

app.Run();
