﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Exercicio_Prova_MongoDB.Models;

    public class PseudoMongoDBContext : DbContext
    {
        public PseudoMongoDBContext (DbContextOptions<PseudoMongoDBContext> options)
            : base(options)
        {
        }

        public DbSet<Exercicio_Prova_MongoDB.Models.Casa> Casa { get; set; } = default!;
    }
