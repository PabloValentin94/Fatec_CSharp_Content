﻿using Microsoft.EntityFrameworkCore;

using Exercicio_Prova_SQL.Models;

namespace Exercicio_Prova_SQL.Data
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options) {  }

        public DbSet<Models.Proprietario> Proprietarios { get; set; }

        public DbSet<Models.Carro> Carros { get; set; }

        public DbSet<Models.Revisao> Revisoes { get; set; }

        public DbSet<Models.Servico> Servicos { get; set; }

        public DbSet<RevisaoServico> Servicos_Executados_Revisao { get; set; }
    }
}
