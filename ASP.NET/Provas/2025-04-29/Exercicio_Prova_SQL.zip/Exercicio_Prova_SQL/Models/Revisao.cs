﻿namespace Exercicio_Prova_SQL.Models
{
    public class Revisao
    {
        public int Id { get; set; }

        public DateOnly Data_Revisao { get; set; }

        public int Km { get; set; }

        public int CarroId { get; set; }

        public Carro? Carro { get; set; }
    }
}
