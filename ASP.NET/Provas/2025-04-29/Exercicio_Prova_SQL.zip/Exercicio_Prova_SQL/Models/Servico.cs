﻿namespace Exercicio_Prova_SQL.Models
{
    public class Servico
    {
        public int Id { get; set; }

        public string? Descricao { get; set; }
    }
}
