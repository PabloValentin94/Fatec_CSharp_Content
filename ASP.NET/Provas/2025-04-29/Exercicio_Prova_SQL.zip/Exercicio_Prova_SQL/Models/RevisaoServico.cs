﻿namespace Exercicio_Prova_SQL.Models
{
    public class RevisaoServico
    {
        public int Id { get; set; }

        public int RevisaoId { get; set; }

        public int ServicoId { get; set; }

        public Revisao? Revisao { get; set; }

        public Servico? Servico { get; set; }
    }
}
