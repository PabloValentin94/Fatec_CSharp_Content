﻿namespace Exercicio_Prova_SQL.Models
{
    public class Proprietario
    {
        public int Id { get; set; }

        public string? Nome { get; set; }

        public string? Cpf { get; set; }

        public string? Celular { get; set; }
    }
}
