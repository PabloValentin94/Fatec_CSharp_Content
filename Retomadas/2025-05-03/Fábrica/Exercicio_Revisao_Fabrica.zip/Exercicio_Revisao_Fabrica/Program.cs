﻿// Execução.

try
{

    // Objetos.

    Fabrica fabrica_01 = new Fabrica("Fábrica 01");

    Fabrica fabrica_02 = new Fabrica("Fábrica 02");

    fabrica_01.Adicionar_Maquina("Máquina 01", DateTime.Now, "01-01", "Vermelha");

    fabrica_01.Adicionar_Maquina("Máquina 02", DateTime.Now, "01-02", "Amarela");

    fabrica_02.Adicionar_Maquina("Máquina 03", DateTime.Now, "02-01", "Verde");

    fabrica_02.Adicionar_Maquina("Máquina 04", DateTime.Now, "02-02", "Azul");

    fabrica_02.Adicionar_Maquina("Máquina 05", DateTime.Now, "02-03", "Roxa");

    Operador operador_01 = new Operador("Tiago");

    Operador operador_02 = new Operador("Vânia");

    // Testes.

    fabrica_01.Listar_Maquinas();

    fabrica_02.Listar_Maquinas();

    await operador_01.Operar_Maquina_Async(fabrica_01, "01-01");

    await operador_01.Operar_Maquina_Async(fabrica_01, "01-03");

    await operador_02.Operar_Maquina_Async(fabrica_02, "02-02");

}

catch (Exception ex)
{

    Console.Clear();

    Console.WriteLine("---------------------------------------------------------------------------------------------------");

    Console.WriteLine($"Erro genérico!\n\nSaída: {ex.Message}");

}

finally
{

    Console.WriteLine("---------------------------------------------------------------------------------------------------");

    Console.ReadKey();

}

// Classes.

abstract class Equipamento
{

    public string? Nome { get; set; }

    public DateTime Data_Fabricacao { get; set; }

    public Equipamento(string nome, DateTime data_fabricacao)
    {

        this.Nome = nome;

        this.Data_Fabricacao = data_fabricacao;

    }

}

class Operador
{

    public string? Nome { get; set; }

    public Operador(string nome)
    {

        this.Nome = nome;

    }

    public async Task Operar_Maquina_Async(Fabrica fabrica, string modelo)
    {

        Console.WriteLine("---------------------------------------------------------------------------------------------------");

        Console.WriteLine($"O(A) operador(a) {this.Nome} está tentando operar a máquina do modelo \"{modelo}\".");

        await Task.Delay(2000);

        Fabrica.Maquina? maquina_encontrada = fabrica.Buscar_Maquina_Pelo_Modelo(modelo);

        try
        {

            if (maquina_encontrada != null)
            {

                Console.WriteLine($"\nO(A) operador(a) {this.Nome} está operando a máquina \"{maquina_encontrada.Nome}\" do modelo \"{maquina_encontrada.Modelo}\".");

                await Task.Delay(3000);

            }

            else
            {

                throw new MaquinaInexistenteException($"Não existe uma máquina com o modelo (\"{modelo}\") especificado!");

            }

        }

        catch (MaquinaInexistenteException ex)
        {

            Console.WriteLine("\n" + ex.Message);

        }

    }

}

class Fabrica
{

    public string? Nome { get; set; }

    private ICollection<Maquina> Maquinas { get; set; } = new List<Maquina>();

    public Fabrica(string nome)
    {

        this.Nome = nome;

    }

    public void Adicionar_Maquina(string nome, DateTime data_fabricacao, string modelo, string observacao)
    {

        this.Maquinas.Add(new Maquina(nome, data_fabricacao, modelo, observacao, this));

        Console.WriteLine("---------------------------------------------------------------------------------------------------");

        Console.WriteLine("Máquina ({0}) adicionada à fábrica especificada ({1}) com sucesso.", this.Maquinas.Last().Nome, this.Maquinas.Last().Fabrica.Nome);

    }

    public void Listar_Maquinas()
    {

        Console.WriteLine("---------------------------------------------------------------------------------------------------");

        Console.WriteLine("Máquinas ({0}):\n\nEstrutura de Listagem: Nome | Modelo | Data de Fabricação | Número de Série\n", this.Nome);

        foreach (Maquina maquina in this.Maquinas)
        {

            Console.WriteLine("{0} | {1} | {2} | {3}", maquina.Nome, maquina.Modelo, maquina.Data_Fabricacao.ToString("dd/MM/yyyy"), maquina.Numero_Serie.ToString("D"));

        }

    }

    public Maquina? Buscar_Maquina_Pelo_Modelo(string modelo)
    {

        Maquina? maquina_encontrada = null;

        foreach (Maquina maquina in this.Maquinas)
        {

            if (maquina.Modelo == modelo)
            {

                maquina_encontrada = maquina;

                break;

            }

        }

        return maquina_encontrada;

    }

    // Classe.

    internal class Maquina : Equipamento
    {

        // Campos.

        private Guid numero_serie;

        private string? observacao;

        // Atributos.

        public string? Modelo { get; set; }

        public string? Hora_Operacao { get; set; }

        public Guid Numero_Serie { get { return this.numero_serie; } }

        public string? Observacao { set { this.observacao = value; } }

        public Fabrica? Fabrica { get; set; }

        public Maquina(string nome, DateTime data_fabricacao, string modelo, string observacao, Fabrica fabrica) : base(nome, data_fabricacao)
        {

            this.Modelo = modelo;

            this.Hora_Operacao = DateTime.Now.ToString("HH:mm:ss");

            this.numero_serie = Guid.NewGuid();

            this.Observacao = observacao;

            this.Fabrica = fabrica;

        }

    }

}

// Exceção.

class MaquinaInexistenteException : Exception
{

    public MaquinaInexistenteException(string message) : base(message) {  }

}