﻿// Execução.

Botao botao = new Botao();

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("Aperte alguma tecla.");

Console.ReadKey();

botao.Simular_Clique();

botao.Simular_Clique();

botao.Simular_Clique();

botao.Simular_Clique();

botao.Simular_Clique();

Console.Clear();

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("Fim da Execução.");

Console.WriteLine("--------------------------------------------------------------------");

Console.ReadKey();

// Delegate.

public delegate void Evento_Clique();

// Classes.

internal class Botao
{

    private event Evento_Clique Clique;

    public Botao()
    {

        Contador_Cliques contador_cliques_botao = new Contador_Cliques();

        this.Clique += contador_cliques_botao.Contar;

    }

    public void Simular_Clique()
    {

        this.Clique.Invoke();

    }

}

internal class Contador_Cliques
{

    private int Quantidade_Cliques = 0;

    public void Contar()
    {

        this.Quantidade_Cliques++;

        Console.Clear();

        Console.WriteLine("--------------------------------------------------------------------");

        Console.WriteLine($"Quantidade de cliques executados: {this.Quantidade_Cliques}.");

        Console.ReadKey();

    }

}