﻿// Execução.

Estoque estoque_produto = new Estoque();

estoque_produto.Verificar_Estoque();

estoque_produto.Vender_Produto(2);

estoque_produto.Verificar_Estoque();

estoque_produto.Vender_Produto(4);

estoque_produto.Verificar_Estoque();

Console.WriteLine("-------------------------------------------------------------------------");

Console.ReadKey();

// Classe de dados de eventos.

internal class EstoqueEventArgs : EventArgs
{

    public string? Nome_Produto { get; set; }

    public int Quantidade_Atual_Produto { get; set; }

}

// Classes.

internal class Estoque
{

    private string? Nome_Produto;

    private int Quantidade_Atual_Produto;

    private int Estoque_Minimo;

    private event EventHandler<EstoqueEventArgs> Estoque_Baixo;

    public Estoque()
    {

        // Valores de teste.

        this.Nome_Produto = "Camisa";

        this.Quantidade_Atual_Produto = 10;

        this.Estoque_Minimo = 5;

        this.Estoque_Baixo += Aviso.Exibir;

    }

    public void Verificar_Estoque()
    {

        Console.WriteLine("-------------------------------------------------------------------------");

        if (this.Quantidade_Atual_Produto < this.Estoque_Minimo)
        {

            this.Estoque_Baixo.Invoke(this, new EstoqueEventArgs()
            {

                Nome_Produto = this.Nome_Produto,

                Quantidade_Atual_Produto = this.Quantidade_Atual_Produto

            });

        }

        else
        {

            Console.WriteLine($"A quantidade disponível do produto \"{this.Nome_Produto}\" atende ao mínimo exigido.");

        }

    }

    public void Vender_Produto(int quantidade)
    {

        if (quantidade <= this.Quantidade_Atual_Produto)
        {

            this.Quantidade_Atual_Produto -= quantidade;

        }

    }

}

internal class Aviso
{

    public static void Exibir(object? sender, EstoqueEventArgs e)
    {

        Console.WriteLine($"Atenção!\n\nA quantidade disponível do produto \"{e.Nome_Produto}\" encontra-se baixa!\n\nQuantidade atual: {e.Quantidade_Atual_Produto}.");

    }

}