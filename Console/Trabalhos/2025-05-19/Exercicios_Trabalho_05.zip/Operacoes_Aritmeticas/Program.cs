﻿// Execução.

Operacao soma = Calculadora.Soma;

Operacao subtracao = Calculadora.Subtracao;

Operacao multiplicacao = Calculadora.Multiplicacao;

Operacao divisao = Calculadora.Divisao;

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("OPERAÇÕES MATEMÁTICAS");

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("Soma: {0}", soma.Invoke(4, 4));

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("Subtração: {0}", subtracao.Invoke(4, 4));

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("Multiplicação: {0}", multiplicacao.Invoke(4, 4));

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("Divisão: {0}", divisao.Invoke(4, 4));

Console.WriteLine("--------------------------------------------------------------------");

Console.ReadKey();

// Delegate.

internal delegate double Operacao(double primeiro_numero, double segundo_numero);

// Classes.

internal class Calculadora
{

    public static double Soma(double primeiro_numero, double segundo_numero)
    {

        double resultado = primeiro_numero + segundo_numero;

        return resultado;

    }

    public static double Subtracao(double primeiro_numero, double segundo_numero)
    {

        double resultado = primeiro_numero - segundo_numero;

        return resultado;

    }

    public static double Multiplicacao(double primeiro_numero, double segundo_numero)
    {

        double resultado = primeiro_numero * segundo_numero;

        return resultado;

    }

    public static double Divisao(double primeiro_numero, double segundo_numero)
    {

        double resultado = primeiro_numero / segundo_numero;

        return resultado;

    }

}