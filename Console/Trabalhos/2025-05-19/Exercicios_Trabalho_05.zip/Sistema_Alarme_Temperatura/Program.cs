﻿// Execução.

Ar_Condicionado ar_condicionado = new Ar_Condicionado();

Console.WriteLine("--------------------------------------------------------------------");

Console.WriteLine("MONITORAMENTO DE TEMPERATURA");

ar_condicionado.Ajustar_Temperatura(100);

ar_condicionado.Ajustar_Temperatura(150.25);

ar_condicionado.Ajustar_Temperatura(0);

ar_condicionado.Ajustar_Temperatura(-1.50);

ar_condicionado.Ajustar_Temperatura(50);

Console.WriteLine("--------------------------------------------------------------------");

Console.ReadKey();

// Classe de dados de eventos.

internal class AlarmeEventArgs : EventArgs
{

    public string? Mensagem { get; set; }

}

// Classes.

internal class Ar_Condicionado
{

    private double Temperatura;

    // Limite máximo.

    private double Limite_Superior;

    // Limite mínimo.

    private double Limite_Inferior;

    // Utilizando um delegate pré-definido no C#.

    private event EventHandler<AlarmeEventArgs> Alarme_Temperatura;

    public Ar_Condicionado()
    {

        // Valores de teste.

        Temperatura = 0;

        Limite_Superior = 100.00;

        Limite_Inferior = 0.00;

        this.Alarme_Temperatura += Monitor.Disparar;

    }

    public void Ajustar_Temperatura(double temperatura)
    {

        Console.WriteLine("--------------------------------------------------------------------");

        this.Temperatura = temperatura;

        if (this.Temperatura > this.Limite_Superior)
        {

            this.Alarme_Temperatura.Invoke(this, new AlarmeEventArgs()
            {

                Mensagem = $"Temperatura atual ({this.Temperatura.ToString()}ºC) " +
                           $"acima do máximo permitido ({this.Limite_Superior.ToString()}ºC)."

            });

        }

        else if (this.Temperatura < this.Limite_Inferior)
        {

            this.Alarme_Temperatura.Invoke(this, new AlarmeEventArgs()
            {

                Mensagem = $"Temperatura atual ({this.Temperatura.ToString()}ºC) " +
                           $"abaixo do mínimo exigido ({this.Limite_Inferior.ToString()}ºC)."

            });

        }

        else
        {

            Console.WriteLine($"Temperatura atual ({this.Temperatura.ToString()}ºC) dentro dos limites " +
                              $"(Entre {this.Limite_Inferior.ToString()}ºC e {this.Limite_Superior.ToString()}°C).");

        }

    }

}

internal class Monitor
{

    public static void Disparar(object? sender, AlarmeEventArgs e)
    {

        Console.WriteLine($"Alarme disparado!\n\n{e.Mensagem}");

    }

}