﻿List<string> nomes_alunos = new List<string>();

bool looping = true;

while (looping)
{

    Console.Clear();

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("1 - Inserir um novo nome.");

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("2 - Remover um nome.");

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("3 - Listar nomes.");

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("4 - Sair.");

    Console.WriteLine("\n");

    Console.Write("Escolha uma das opções do menu acima: ");

    int opcao = int.Parse(Console.ReadLine() ?? "4");

    Console.Clear();

    Console.WriteLine("---------------------------------------------------------------");

    switch (opcao)
    {

        case 1:

            Console.Write("Digite um nome: ");

            string novo_nome = Console.ReadLine() ?? "";

            if (!nomes_alunos.Contains(novo_nome))
            {

                nomes_alunos.Add(novo_nome);

            }

            else
            {

                Console.WriteLine("\nNome já salvo.");

                Console.ReadKey();

            }

        break;

        case 2:

            Console.Write("Digite o nome a ser removido: ");

            string nome_especificado = Console.ReadLine() ?? "";

            if (nomes_alunos.Contains(nome_especificado))
            {

                nomes_alunos.Remove(nome_especificado);

            }

            else
            {

                Console.WriteLine("\nNome não encontrado.");

                Console.ReadKey();

            }

        break;

        case 3:

            if (nomes_alunos.Count > 0)
            {

                Console.WriteLine("Nomes salvos:\n");

                for (int i = 0; i < nomes_alunos.Count; i++)
                {

                    Console.WriteLine("- " + nomes_alunos[i]);

                    if (i < nomes_alunos.Count - 1)
                    {

                        Console.Write("\n");

                    }

                }

            }

            else
            {

                Console.WriteLine("Não há nada a ser exibido.");

            }

            Console.ReadKey();

        break;

        default:

            looping = false;

        break;

    }

}

Console.WriteLine("Saindo do menu de opções...");

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();