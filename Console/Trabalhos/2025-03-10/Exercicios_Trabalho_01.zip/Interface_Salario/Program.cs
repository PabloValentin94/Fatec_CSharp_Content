﻿// Objetos.

ISalario funcionario_horista = new Funcionario_Horista("Gabriel", 200, 15);

ISalario funcionario_mensalista = new Funcionario_Mensalista("Pablo", 1, 1512);

// Exibições.

funcionario_horista.Calcular_Salario();

funcionario_mensalista.Calcular_Salario();

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Interface.

public interface ISalario
{

    public void Calcular_Salario();

}

// Classes.

public class Funcionario_Horista : ISalario
{

    private string _nome = "";

    public string nome { get { return this._nome; } set { this._nome = value; } }

    private double _horas_trabalhadas;

    public double horas_trabalhadas { get { return this._horas_trabalhadas; } set { this._horas_trabalhadas = value; } }

    private double _valor_hora;

    public double valor_hora { get { return this._valor_hora; } set { this._valor_hora = value; } }

    public Funcionario_Horista(string nome, double horas_trabalhadas, double valor_hora)
    {

        this.nome = nome;

        this.horas_trabalhadas = horas_trabalhadas;

        this.valor_hora = valor_hora;

    }

    public void Calcular_Salario()
    {

        double salario = this.horas_trabalhadas * this.valor_hora;

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Salário de {this.nome} (Horista) em {this.horas_trabalhadas} hora(s) de trabalho: R${Math.Round(salario, 2)}");

    }

}

public class Funcionario_Mensalista : ISalario
{

    private string _nome = "";

    public string nome { get { return this._nome; } set { this._nome = value; } }

    private double _meses_trabalhados;

    public double meses_trabalhados { get { return this._meses_trabalhados; } set { this._meses_trabalhados = value; } }

    private double _valor_mensal;

    public double valor_mensal { get { return this._valor_mensal; } set { this._valor_mensal = value; } }

    public Funcionario_Mensalista(string nome, double meses_trabalhados, double valor_mensal)
    {

        this.nome = nome;

        this.meses_trabalhados = meses_trabalhados;

        this.valor_mensal = valor_mensal;

    }

    public void Calcular_Salario()
    {

        double salario = this.meses_trabalhados * this.valor_mensal;

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Salário de {this.nome} (Mensalista) em {this.meses_trabalhados} mês(es) de trabalho: R${Math.Round(salario, 2)}");

    }

}