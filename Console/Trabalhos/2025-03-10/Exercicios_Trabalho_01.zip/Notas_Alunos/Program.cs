﻿double[,] notas_alunos = new double[3, 3];

int indice_aluno = 0;

while (indice_aluno < notas_alunos.GetLength(0))
{

    Console.WriteLine("---------------------------------------------------------------");

    indice_aluno++;

    for (int i = 0; i < notas_alunos.GetLength(1); i++)
    {

        Console.Write($"Insira a {i + 1}ª nota do {indice_aluno}º aluno: ");

        notas_alunos[indice_aluno - 1, i] = double.Parse(Console.ReadLine() ?? "0");

        if (i < 2)
        {

            Console.Write("\n");

        }

    }

}

Console.Clear();

indice_aluno = 0;

double[] medias = new double[3] { 0, 0, 0 };

double media_geral = 0;

while (indice_aluno < notas_alunos.GetLength(0))
{

    indice_aluno++;

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine($"Notas do {indice_aluno}º aluno:\n");

    for (int j = 0; j < notas_alunos.GetLength(1); j++)
    {

        Console.WriteLine(notas_alunos[indice_aluno - 1, j]);

        medias[indice_aluno - 1] += notas_alunos[indice_aluno - 1, j];

    }

    medias[indice_aluno - 1] /= notas_alunos.GetLength(1);

    media_geral += medias[indice_aluno - 1];

}

media_geral /= notas_alunos.GetLength(0);

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

Console.Clear();

Console.WriteLine("---------------------------------------------------------------");

for (int k = 0; k < notas_alunos.GetLength(0); k++)
{

    Console.WriteLine($"Média do {k + 1}º aluno: " + Math.Round(medias[k], 2));

    if (k < 2)
    {

        Console.Write("\n");

    }

}

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine($"Média Geral: " + Math.Round(media_geral, 2));

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();