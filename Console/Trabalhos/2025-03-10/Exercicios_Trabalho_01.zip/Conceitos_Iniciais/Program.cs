﻿// Objetos.

Carro objeto_carro = new Carro("Ford", "CXR-2620", 4);

Moto objeto_moto = new Moto("Suzuki", "CEY-4409", true);

// Exibições.

objeto_carro.Exibir_Informacoes();

objeto_moto.Exibir_Informacoes();

objeto_carro.Alterar_Placa("CZR-2620");

objeto_carro.Exibir_Informacoes();

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Classes.

public abstract class Veiculo
{

    private string? _marca;

    private string? _placa;

    public string? marca { get { return this._marca; } } // Atributo somente leitura.

    public string? placa { set { this._placa = value; } } // Atributo somente gravação.

    public Veiculo(string marca, string placa)
    {

        this._marca = marca; // Alterando o valor do campo.

        this.placa = placa; // Alterando o valor do campo, através de seu respectivo atributo.

    }

    public virtual void Exibir_Informacoes()
    {

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine($"Marca do veículo especificado: {this.marca}.");
        Console.WriteLine($"Placa do veículo especificado: {this._placa}."); // Como o atributo é somente leitura, só conseguimos exibir seu valor usando o campo privado, dentro da própria classe.

    }

    public void Alterar_Placa(string placa)
    {

        this.placa = placa;

    }

}

public class Carro : Veiculo
{

    private int _portas;

    public int portas { get { return this._portas; } set { this._portas = value; } }

    public Carro(string marca, string placa, int portas) : base(marca, placa)
    {

        this.portas = portas;

    }

    public override void Exibir_Informacoes()
    {

        base.Exibir_Informacoes();

        Console.WriteLine($"Quantidade de portas do veículo: {this.portas}.");

    }

}

public class Moto : Veiculo
{

    private bool _partida_eletrica;

    public bool partida_eletrica { get { return this._partida_eletrica; } set { this._partida_eletrica = value; } }

    public Moto(string marca, string placa, bool partida_eletrica) : base(marca, placa)
    {

        this.partida_eletrica = partida_eletrica;

    }

    public override void Exibir_Informacoes()
    {

        base.Exibir_Informacoes();

        Console.WriteLine($"Tipo de partida do veículo:{((this.partida_eletrica) ? "" : " não")} elétrica.");

    }

}