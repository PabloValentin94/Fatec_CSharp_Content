﻿using System.Collections; // Namespace do ArrayList.

ArrayList produtos = new ArrayList();

bool looping = true;

while (looping)
{

    Console.Clear();

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("1 - Inserir um novo produto.");

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("2 - Remover um produto.");

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("3 - Listar produtos.");

    Console.WriteLine("---------------------------------------------------------------");

    Console.WriteLine("4 - Sair.");

    Console.WriteLine("\n");

    Console.Write("Escolha uma das opções do menu acima: ");

    int opcao = int.Parse(Console.ReadLine() ?? "4");

    Console.Clear();

    Console.WriteLine("---------------------------------------------------------------");

    switch (opcao)
    {

        case 1:

            Console.Write("Digite um nome para o produto: ");

            string novo_nome = Console.ReadLine() ?? "";

            bool permitido = true;

            foreach (Produto produto in produtos)
            {

                if (produto.nome == novo_nome)
                {

                    permitido = false;

                    break;

                }

            }

            if (permitido)
            {

                produtos.Add(new Produto(novo_nome));

            }

            else
            {

                Console.WriteLine("\nProduto já cadastrado.");

                Console.ReadKey();

            }

        break;

        case 2:

            Console.Write("Digite o índice do produto a ser removido (Veja na listagem de produtos.): ");

            int indice_especificado = int.Parse(Console.ReadLine() ?? "-1");

            if (indice_especificado < 0 || indice_especificado >= produtos.Count)
            {

                Console.WriteLine("\nProduto não encontrado.");

                Console.ReadKey();

            }

            else
            {

                produtos.RemoveAt(indice_especificado);

            }

        break;

        case 3:

            if (produtos.Count > 0)
            {

                Console.WriteLine("Produtos cadastrados:\n");

                for (int i = 0; i < produtos.Count; i++)
                {

                    Console.WriteLine(i + " - " + ((Produto) produtos[i]).nome);

                    if (i < produtos.Count - 1)
                    {

                        Console.Write("\n");

                    }

                }

            }

            else
            {

                Console.WriteLine("Não há nada a ser exibido.");

            }

            Console.ReadKey();

        break;

        default:

            looping = false;

        break;

    }

}

Console.WriteLine("Saindo do menu de opções...");

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Classe.

class Produto
{

    private string _nome = "";

    public string nome { get { return this._nome; } set { this._nome = value; } }

    public Produto(string nome)
    {

        this.nome = nome;

    }

}