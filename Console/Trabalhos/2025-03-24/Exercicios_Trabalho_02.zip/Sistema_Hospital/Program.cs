﻿try
{

    // Objetos.

    List<Consulta> lista_consultas = new List<Consulta>()
    {

        new Consulta("24/03/2025", "Febre alta com sinais de dengue.", new Paciente("Amauri", 19, ["Dengue", "Gripe", "Asma"]), new Medico("Renam", 35, "Doenças Gerais", "00000000-0/BR")),

        new Consulta("15/01/2022", "Intensas dores de barriga.", new Paciente("Pablo", 19, ["Gripe"]), new Medico("Garibaldo", 42, "Dores Renais", "11111111-1/BR"))

    };

    // Detalhes das consultas.

    Console.WriteLine("----------------------------------------------------------------");

    Console.WriteLine("Listagem de Consultas:");

    foreach (Consulta consulta in lista_consultas)
    {

        string doencas = "";

        for (int i = 0; i < consulta.paciente.historico_doencas.Length; i++)
        {

            if (i > 0)
            {

                doencas += (i == consulta.paciente.historico_doencas.Length - 1) ? " e " : ", ";

            }

            doencas += $"{consulta.paciente.historico_doencas[i]}";

        }

        Console.WriteLine($"\nData: {consulta.data_consulta};" +
                          $"\nPaciente: {consulta.paciente.nome} ({consulta.paciente.idade} anos.);" +
                          $"\nHistórico de Doenças do Paciente: {doencas};" +
                          $"\nMédico ({consulta.medico.crm}): {consulta.medico.nome} ({consulta.medico.idade} anos.);" +
                          $"\nEspecialidade do Médico: {consulta.medico.especialidade};" +
                          $"\nDiagnóstico: {consulta.diagnostico}");

    }

    Console.WriteLine("----------------------------------------------------------------");

    Console.WriteLine("Veja o código para mais detalhes.");

    Console.WriteLine("----------------------------------------------------------------");

}

catch (Exception ex)
{

    Console.WriteLine(ex.Message);

}

finally
{

    Console.ReadKey();

}

// Classes.

abstract class Pessoa
{

    // Os campos são gerados automaticamente pelo compilador.

    public string? nome { get; set; }

    public int idade { get; set; }

    public Pessoa(string nome, int idade)
    {

        this.nome = nome;

        this.idade = idade;

    }

}

class Paciente : Pessoa
{

    // Os campos são gerados automaticamente pelo compilador.

    public string[]? historico_doencas { get; set; }

    public Paciente(string nome, int idade, string[] historico_doencas) : base(nome, idade)
    {

        this.historico_doencas = historico_doencas;

    }

}

class Medico : Pessoa
{

    // Os campos são gerados automaticamente pelo compilador.

    public string? especialidade { get; set; }

    public string? crm { get; set; }

    public Medico(string nome, int idade, string especialidade, string crm) : base(nome, idade)
    {

        this.especialidade = especialidade;

        this.crm = crm;

    }

}

class Consulta
{

    // Os campos são gerados automaticamente pelo compilador.

    public string? data_consulta { get; set; }

    public string? diagnostico { get; set; }

    public Paciente? paciente { get; set; }

    public Medico? medico { get; set; }

    public Consulta(string data_consulta, string diagnostico, Paciente paciente, Medico medico)
    {

        this.data_consulta = data_consulta;

        this.diagnostico = diagnostico;

        this.paciente = paciente;

        this.medico = medico;

    }

}