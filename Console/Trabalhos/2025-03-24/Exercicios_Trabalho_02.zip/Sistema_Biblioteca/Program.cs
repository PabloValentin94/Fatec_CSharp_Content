﻿// Objetos.

List<Livro> livros = new List<Livro>()
{

    new Livro("O Príncipe", "Nicolau Maquiavel", "Disponível"),
    new Livro("Alice no País das Maravilhas", "Charles Lutwidge Dodgson", "Disponível"),
    new Livro("Memórias Póstumas de Brás Cubas", "Machado de Assis", "Disponível")

};

List<Usuario> usuarios = new List<Usuario>()
{

    new Usuario("Pablo Valentin", new List<Livro>()),
    new Usuario("Thiago Figueredo", new List<Livro>())

};

List<Emprestimo> emprestimos = new List<Emprestimo>();

// Interface de Usuário.

bool looping = true;

while (looping)
{

    try
    {

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("1 - Emprestar livro.");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("2 - Devolver um livro.");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("3 - Listar livros.");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("4 - Listar usuários.");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("5 - Listar empréstimos.");

        Console.WriteLine("---------------------------------------------------------------");

        Console.WriteLine("6 - Sair.");

        Console.WriteLine("\n");

        Console.Write("Escolha uma das opções do menu acima: ");

        int opcao = int.Parse(Console.ReadLine() ?? "6");

        Console.Clear();

        Console.WriteLine("---------------------------------------------------------------");

        switch (opcao)
        {

            case 1:

                Console.Write("Digite o ID do livro desejado: ");
                int id_livro_desejado = int.Parse(Console.ReadLine() ?? "0");

                if (!livros.Any(livro => livro.id == id_livro_desejado))
                {

                    throw new ArgumentException("Não existe nenhum livro com o ID informado.");

                }

                else if (livros[Livro.Obter_Indice_List(id_livro_desejado, livros)].status != "Disponível")
                {

                    throw new InvalidOperationException("O livro especificado já encontra-se em uso. Operação cancelada.");

                }

                else
                {

                    Console.Write("\nDigite o ID do usuário que está emprestando o livro especificado: ");
                    int id_usuario_requisitor = int.Parse(Console.ReadLine() ?? "0");

                    if (!usuarios.Any(usuario => usuario.id == id_usuario_requisitor))
                    {

                        throw new ArgumentException("Não existe nenhum usuário com o ID informado.");

                    }

                    else if (emprestimos.Any(emprestimo => emprestimo.usuario.id == id_usuario_requisitor &&
                                            DateTime.Compare(DateTime.Now, DateTime.Parse(emprestimo.data_devolucao)) > 0 &&
                                            emprestimo.situacao != "Arquivado"))
                    {

                        throw new InvalidOperationException("O usuário informado possui empréstimos de livros com devolução atrasada! Operação cancelada.");

                    }

                    else
                    {

                        Emprestimo novo_emprestimo = new Emprestimo(livros[Livro.Obter_Indice_List(id_livro_desejado, livros)], usuarios[Usuario.Obter_Indice_List(id_usuario_requisitor, usuarios)], DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));

                        novo_emprestimo.data_devolucao = DateTime.Parse(novo_emprestimo.data_emprestimo).AddDays(8).ToString("dd/MM/yyyy");

                        emprestimos.Add(novo_emprestimo);

                        Console.WriteLine("\nLivro emprestado com sucesso.");

                        Console.ReadKey();

                    }

                }

            break;

            case 2:

                Console.Write("Digite o ID do livro a ser devolvido: ");
                int id_livro_emprestado = int.Parse(Console.ReadLine() ?? "0");

                if (!livros.Any(livro => livro.id == id_livro_emprestado))
                {

                    throw new ArgumentException("Não existe nenhum livro com o ID informado.");

                }

                else
                {

                    if (livros[Livro.Obter_Indice_List(id_livro_emprestado, livros)].status != "Emprestado")
                    {

                        throw new InvalidOperationException("O livro especificado já encontra-se disponível. Nada a ser feito.");

                    }

                    else
                    {

                        foreach (Emprestimo emprestimo in emprestimos)
                        {

                            if (emprestimo.livro.id == id_livro_emprestado && emprestimo.situacao != "Arquivado")
                            {

                                emprestimo.usuario.livros_emprestados.RemoveAt(Livro.Obter_Indice_List(id_livro_emprestado, emprestimo.usuario.livros_emprestados));

                                emprestimo.situacao = "Arquivado";

                                livros[Livro.Obter_Indice_List(id_livro_emprestado, livros)].status = "Disponível";

                                Console.WriteLine("\nLivro devolvido com sucesso.");

                                Console.ReadKey();

                                break;

                            }

                        }

                    }

                }

            break;

            case 3:

                Console.WriteLine("Listagem de Livros:");

                Console.WriteLine($"\nQuantidade de Livros Cadastrados: {livros.Count}.");

                if (livros.Count > 0)
                {

                    foreach (Livro livro in livros)
                    {

                        Console.WriteLine($"\nID: {livro.id};" +
                                          $"\nTítulo: {livro.titulo};" +
                                          $"\nAutor: {livro.autor};" +
                                          $"\nStatus: {livro.status}.");

                    }

                }

                else
                {

                    Console.WriteLine("\nNada a ser exibido.");

                }

                Console.ReadKey();

            break;

            case 4:

                Console.WriteLine("Listagem de Usuários:");

                Console.WriteLine($"\nQuantidade de Usuários Cadastrados: {usuarios.Count}.");

                if (usuarios.Count > 0)
                {

                    foreach (Usuario usuario in usuarios)
                    {

                        Console.WriteLine($"\nID: {usuario.id};" +
                                          $"\nNome: {usuario.nome};" +
                                          $"\nQuantidade de Livros Emprestados: {usuario.livros_emprestados.Count}.");

                    }

                }

                else
                {

                    Console.WriteLine("\nNada a ser exibido.");

                }

                Console.ReadKey();

            break;

            case 5:

                Console.WriteLine("Listagem de Empréstimos:");

                Console.WriteLine($"\nQuantidade de Empréstimos de Livros Existentes: {emprestimos.Count}.");

                if (emprestimos.Count > 0)
                {

                    foreach (Emprestimo emprestimo in emprestimos)
                    {

                        Console.WriteLine($"\nRequisitor: {emprestimo.usuario.nome};" +
                                          $"\nLivro: {emprestimo.livro.titulo} ({emprestimo.livro.autor});" +
                                          $"\nData de Empréstimo: {emprestimo.data_emprestimo};" +
                                          $"\nData Máxima de Devolução: {emprestimo.data_devolucao};" +
                                          $"\nSituação do Empréstimo: {emprestimo.situacao}.");

                    }

                }

                else
                {

                    Console.WriteLine("\nNada a ser exibido.");

                }

                Console.ReadKey();

            break;

            default:

                looping = false;

            break;

        }

    }

    catch (ArgumentException ex)
    {

        Console.WriteLine($"\nExceção de IDs.\n\nSaída: {ex.Message}");

        Console.ReadKey();

    }

    catch (InvalidOperationException ex)
    {

        Console.WriteLine($"\nExceção de Operações.\n\nSaída: {ex.Message}");

        Console.ReadKey();

    }

    catch (Exception ex)
    {

        Console.WriteLine($"\nExceção genérica.\n\nSaída: {ex.Message}");

        Console.ReadKey();

    }

}

Console.WriteLine("Saindo do menu de opções...");

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

// Classes.

class Livro
{

    private static int gerenciador_ids = 0;

    // Os campos são gerados automaticamente pelo compilador.

    public int id { get; set; }

    public string? titulo { get; set; }

    public string? autor { get; set; }

    public string? status { get; set; }

    public Livro(string titulo, string autor, string status)
    {

        gerenciador_ids++;

        this.id = gerenciador_ids;

        this.titulo = titulo;

        this.autor = autor;

        this.status = status;

    }

    public static int Obter_Indice_List(int id, List<Livro> lista_analisada)
    {

        int indice = 0;

        foreach (Livro livro in lista_analisada)
        {

            if (livro.id != id)
            {

                indice++;

            }

            else
            {

                break;

            }

        }

        return indice;

    }

}

class Usuario
{

    private static int gerenciador_ids = 0;

    // Os campos são gerados automaticamente pelo compilador.

    public int id { get; set; }

    public string? nome { get; set; }

    public List<Livro>? livros_emprestados { get; set; }

    public Usuario(string nome, List<Livro> livros_emprestados)
    {

        gerenciador_ids++;

        this.id = gerenciador_ids;

        this.nome = nome;

        this.livros_emprestados = livros_emprestados;

    }

    public static int Obter_Indice_List(int id, List<Usuario> lista_analisada)
    {

        int indice = 0;

        foreach (Usuario usuario in lista_analisada)
        {

            if (usuario.id != id)
            {

                indice++;

            }

            else
            {

                break;

            }

        }

        return indice;

    }

}

class Emprestimo
{

    // Os campos são gerados automaticamente pelo compilador.

    public Livro? livro { get; set; }

    public Usuario? usuario { get; set; }

    public string? data_emprestimo { get; set; }

    public string? data_devolucao { get; set; }

    public string? situacao { get; set; }

    public Emprestimo(Livro livro, Usuario usuario, string data_emprestimo)
    {

        if (livro.status == "Disponível")
        {

            livro.status = "Emprestado";

            usuario.livros_emprestados.Add(livro);

            this.livro = livro;

            this.usuario = usuario;

            this.data_emprestimo = data_emprestimo;

            this.situacao = "Não arquivado (Aguardando devolução.)";

        }

        else
        {

            throw new InvalidOperationException($"Este livro ({livro.titulo}) já foi emprestado por alguém!");

        }

    }

}

// Exceções.

class ArgumentException : Exception
{

    public ArgumentException(string message) : base(message) {  }

}

class InvalidOperationException : Exception
{

    public InvalidOperationException(string message) : base(message) {  }

}