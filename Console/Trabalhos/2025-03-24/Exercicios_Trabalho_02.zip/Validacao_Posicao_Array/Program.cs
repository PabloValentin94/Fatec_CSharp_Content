﻿double[] numeros = new double[10] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

while (true)
{

    try
    {

        Console.Clear();

        Console.Write("Digite um valor numérico: ");
        double numero = double.Parse(Console.ReadLine());

        Console.Write($"\nInforme uma das posições do array ({numeros.Length} disponíveis.): ");
        int posicao = int.Parse(Console.ReadLine());

        // Um usuário comum não sabe que os índices de um array começam no zero, então subtraímos um da posição informada.

        numeros[posicao - 1] = numero;

        Console.WriteLine("\nValor inserido no array com sucesso.");

        Console.WriteLine($"\nNúmero presente na posição {posicao} (Usuário), cujo índice é {posicao - 1} (Programa): {numeros[posicao - 1]}");

        break; // Interrompendo o looping.

    }

    catch (FormatException ex)
    {

        Console.WriteLine($"\nO valor deve ser um número real, e a posição, um número inteiro!\n\nSaída: {ex.Message}");

    }

    catch (IndexOutOfRangeException ex)
    {

        Console.WriteLine($"\nA posição informada está fora do intervalo do array!\n\nSaída: {ex.Message}");

    }

    finally
    {

        Console.ReadKey();

    }

}