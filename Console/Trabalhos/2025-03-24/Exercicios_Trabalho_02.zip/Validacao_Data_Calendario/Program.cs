﻿while (true)
{

    try
    {

        Console.Clear();

        Console.Write("Digite uma data (Padrão: dd/MM/yyyy): ");
        string data_calendario = Console.ReadLine();

        DateTime data_retornada_validacao; // A saída do método abaixo será armazenada nessa variável.

        if (DateTime.TryParseExact(data_calendario.ToString(), "dd/MM/yyyy", new System.Globalization.CultureInfo("pt-br"), System.Globalization.DateTimeStyles.None, out data_retornada_validacao))
        {

            Console.WriteLine($"\nA data passada ({data_retornada_validacao.ToString("dd/MM/yyyy")}) está no padrão correto.");

            break;

        }

        else
        {

            throw new Exception("A data passada não está no padrão correto!");

        }

    }

    // O tratamento abaixo é desnecesário, pois a data passada vem como uma "string", mas é implementado por garantia.

    catch (FormatException ex)
    {

        Console.WriteLine($"\nO valor passado deve ser uma data!\n\nSaída: {ex.Message}");

    }

    catch (Exception ex)
    {

        Console.WriteLine($"\nSaída: {ex.Message}");

    }

    finally
    {

        Console.ReadKey();

    }

}