﻿try
{

    Console.WriteLine("Conteúdo do arquivo de texto:\n");

    // Recomendo que troque o caminho de acordo com a estrutura de pastas da sua máquina, garantindo o funcionamento correto.

    string conteudo_arquivo = File.ReadAllText(Path.GetFullPath("../../../Arquivo.txt"));

    Console.WriteLine(conteudo_arquivo);

}

catch (FileNotFoundException ex)
{

    Console.WriteLine($"Arquivo solicitado não encontrado!\n\nSaída: {ex.Message}");

}

catch (UnauthorizedAccessException ex)
{

    Console.WriteLine($"Você não tem permissão para abrir o arquivo solicitado!\n\nSaída: {ex.Message}");

}

catch (Exception ex)
{

    Console.WriteLine($"Saída: {ex.Message}");

}

finally
{

    Console.WriteLine("\nFechando programa.");

    Console.ReadKey();

}