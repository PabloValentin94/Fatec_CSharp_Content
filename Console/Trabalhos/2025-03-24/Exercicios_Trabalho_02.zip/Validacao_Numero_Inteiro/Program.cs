﻿while (true)
{

    try
    {

        Console.Clear();

        Console.Write("Digite um número inteiro: ");
        int numero = int.Parse(Console.ReadLine());

        Console.WriteLine($"\nO valor passado ({numero}) é um número inteiro.");

        break; // Interrompendo o looping.

    }

    catch (FormatException ex)
    {

        Console.WriteLine($"\nO valor passado deve ser um número inteiro!\n\nSaída: {ex.Message}");

    }

    catch (Exception ex)
    {

        Console.WriteLine($"\nSaída: {ex.Message}");

    }

    finally
    {

        Console.ReadKey();

    }

}