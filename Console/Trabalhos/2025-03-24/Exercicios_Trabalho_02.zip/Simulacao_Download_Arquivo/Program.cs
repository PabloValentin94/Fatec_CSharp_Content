﻿try
{

    // Objeto

    Gerenciador_Downloads gerenciador = new Gerenciador_Downloads();

    await gerenciador.Baixar_Arquivo_Async();

}

catch (Exception ex)
{

    Console.WriteLine($"\nSaída: {ex.Message}");

}

finally
{

    Console.ReadKey();

}

// Classe.

class Gerenciador_Downloads
{

    public async Task Baixar_Arquivo_Async()
    {

        Console.WriteLine("Baixando arquivo...");

        await Task.Delay(1000);

        Task status = this.Verificar_Status_Download();

        Task preparacao = this.Preparar_Arquivo();

        // Espera as Tasks especificadas serem concluídas antes de prosseguir (Maneira comum.).

        // await status;

        // await preparacao;

        // Espera as Tasks especificadas serem concluídas antes de prosseguir (Maneira alternativa.).

        await Task.WhenAll(status, preparacao);

        await Task.Delay(1000);

        Console.WriteLine("\nArquivo baixado com sucesso.");

    }

    private async Task Verificar_Status_Download()
    {

        await Task.Delay(1500);

        Console.WriteLine("\nDownload em andamento...");

        await Task.Delay(1000);

        Console.WriteLine("\nDownload em andamento...");

        await Task.Delay(1000);

        Console.WriteLine("\nDownload em andamento...");

        await Task.Delay(1000);

        Console.WriteLine("\nDownload em andamento...");

        await Task.Delay(1500);

    }

    private async Task Preparar_Arquivo()
    {

        await Task.Delay(1000);

        Console.WriteLine("\nLendo o arquivo...");

        await Task.Delay(1000);

        Console.WriteLine("\nAplicando o método de compactação...");

        await Task.Delay(1000);

        Console.WriteLine("\nGerando uma versão compactada do arquivo...");

        await Task.Delay(1000);

        Console.WriteLine("\nDisponibilizando o arquivo compactado para o usuário...");

        await Task.Delay(500);

    }

}