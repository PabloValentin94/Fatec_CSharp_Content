﻿try
{

    // Objetos.

    List<Aluno> lista_alunos = new List<Aluno>()
    {

        new Aluno("Pablo Valentin", 19),

        new Aluno("Thiago Figueredo", 38)

    };

    List<Professor> lista_professores = new List<Professor>()
    {

        new Professor("Joice Nicola", "Inglês Avançado"),

        new Professor("Thiago Pignatti", "Espanhol Intermediário")

    };

    List<Curso> lista_cursos = new List<Curso>()
    {

        new Curso("Inglês", 9, lista_professores[0]),

        new Curso("Espanhol", 9, lista_professores[1])

    };

    List<Matricula> lista_matriculas = new List<Matricula>()
    {

        new Matricula("05/02/2024", lista_alunos[0], lista_cursos[0]),

        new Matricula("05/02/2024", lista_alunos[1], lista_cursos[0]),

        new Matricula("05/02/2023", lista_alunos[1], lista_cursos[1]),

    };

    // Saída.

    Console.WriteLine($"Quantidade de Alunos cadastrados: {lista_alunos.Count};\n" +
                      $"Quantidade de Professores cadastrados: {lista_professores.Count};\n" +
                      $"Quantidade de Cursos cadastrados: {lista_cursos.Count};\n" +
                      $"Quantidade de Matrículas cadastradas: {lista_matriculas.Count}.");

    Console.WriteLine("\nVeja o código para mais detalhes.");

}

catch (Exception ex)
{

    Console.WriteLine(ex.Message);

}

finally
{

    Console.ReadKey();

}

// Classes.

class Aluno
{

    // Os campos são gerados automaticamente pelo compilador.

    public string? nome { get; set; }

    public int idade { get; set; }

    public Aluno(string nome, int idade)
    {

        this.nome = nome;

        this.idade = idade;

    }

}

class Professor
{

    // Os campos são gerados automaticamente pelo compilador.

    public string? nome { get; set; }

    public string? especializacao { get; set; }

    public Professor(string nome, string especializacao)
    {

        this.nome = nome;

        this.especializacao = especializacao;

    }

}

class Curso
{

    // Os campos são gerados automaticamente pelo compilador.

    public string? nome_curso { get; set; }

    public int meses_duracao { get; set; }

    public Professor? professor_responsavel { get; set; }

    public Curso(string nome_curso, int meses_duracao, Professor professor_responsavel)
    {

        this.nome_curso = nome_curso;

        this.meses_duracao = meses_duracao;

        this.professor_responsavel = professor_responsavel;

    }

}

class Matricula
{

    // Os campos são gerados automaticamente pelo compilador.

    public string data_matricula { get; set; }

    public Aluno? aluno { get; set; }

    public Curso? curso { get; set; }

    public Matricula(string data_matricula, Aluno aluno, Curso curso)
    {

        this.data_matricula = data_matricula;

        this.aluno = aluno;

        this.curso = curso;

    }

}