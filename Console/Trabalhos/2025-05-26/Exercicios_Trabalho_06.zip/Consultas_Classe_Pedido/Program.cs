﻿// Recursos (Namespaces).

using Consultas_Classe_Pedido;

// Objetos.

List<Cliente> clientes = new List<Cliente>()
{

    new Cliente("Yuri", "123,456,789-10"),
    new Cliente("Wesley", "109.876.543-21"),
    new Cliente("Travis", "132.465.867-90")

};

List<Produto> produtos = new List<Produto>()
{

    new Produto("Celular", 1000),
    new Produto("Laptop", 5000),
    new Produto("PC", 10000),
    new Produto("SmartWatch", 500),
    new Produto("Chaveiro", 20)

};

List<Pedido> pedidos = new List<Pedido>()
{

    new Pedido(new DateOnly(2020, 10, 12), clientes[0], new List<Item>()
    {

        new Item(1, produtos[3])

    }),

    new Pedido(new DateOnly(2020, 10, 10), clientes[0], new List<Item>()
    {

        new Item(2, produtos[0]),
        new Item(1, produtos[1])

    }),

    new Pedido(new DateOnly(2021, 12, 20), clientes[1], new List<Item>()
    {

        new Item(1, produtos[2])

    }),

    new Pedido(new DateOnly(2021, 12, 24), clientes[1], new List<Item>()
    {

        new Item(2, produtos[0]),
        new Item(2, produtos[1])

    }),

    new Pedido(new DateOnly(2022, 11, 15), clientes[2], new List<Item>()
    {

        new Item(1, produtos[3])

    }),

    new Pedido(new DateOnly(2022, 11, 16), clientes[2], new List<Item>()
    {

        new Item(5, produtos[4])

    })

};

/*

    Consultas:

        A) Pedidos agrupados por clientes;
        B) Clientes com pedidos acima de R$500,00;
        C) Valor total gasto por cada cliente.
 
*/

// A:

IEnumerable<IGrouping<Cliente?, Pedido>> pedidos_clientes = pedidos.OrderBy(pedido => pedido.Data_Pedido).GroupBy(pedido => pedido.Cliente);

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("PEDIDOS DOS CLIENTES");

Console.Write("------------------------------------------------------------------------------------");

foreach (IGrouping<Cliente?, Pedido> pedidos_cliente in pedidos_clientes)
{

    Console.WriteLine("\nPedidos ({0}):", pedidos_cliente.Key?.Nome);

    foreach (Pedido pedido in pedidos_cliente)
    {

        Console.WriteLine("\n    Pedido ({0}):", pedido.Data_Pedido.ToString("dd/MM/yyyy"));

        Console.WriteLine("\n        Itens:");

        for (int i = 0; i < pedido.Itens.Count; i++)
        {

            Console.Write($"\n            - {pedido.Itens[i].Produto?.Nome} | {pedido.Itens[i].Quantidade} unidade(s)");

            Console.WriteLine((i == pedido.Itens.Count - 1) ? "." : ";");

        }

        Console.WriteLine("\n        Valor do pedido: {0}", pedido.Valor.ToString("C2"));

    }

}

// B:

var nomes_pesquisa_clientes = pedidos.Where(pedido => pedido.Valor > 500).GroupBy(pedido => pedido.Cliente).Select(pedidos_cliente => new
{

    Nome = pedidos_cliente.Key?.Nome,

    Quantidade_Pedidos_Validos = pedidos_cliente.Count()

});

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("CLIENTES COM PEDIDOS ACIMA DE R$500,00");

Console.Write("------------------------------------------------------------------------------------");

foreach (var cliente in nomes_pesquisa_clientes)
{

    Console.WriteLine($"\n- {cliente.Nome} (Quantidade de pedidos retornados: {cliente.Quantidade_Pedidos_Validos}.)");

}

// C:

var gastos_totais_clientes = pedidos.GroupBy(pedido => pedido.Cliente).Select(pedidos_cliente => new
{

    Nome = pedidos_cliente.Key?.Nome,

    Gasto_Total = pedidos_cliente.Sum(pedido => pedido.Valor)

});

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("VALOR TOTAL GASTO PELOS CLIENTES");

Console.Write("------------------------------------------------------------------------------------");

foreach (var cliente in gastos_totais_clientes)
{

    Console.WriteLine($"\n - {cliente.Nome} ({cliente.Gasto_Total.ToString("C2")})");

}

Console.WriteLine("------------------------------------------------------------------------------------");

Console.ReadKey();