﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consultas_Classe_Pedido
{

    class Item
    {

        public int Quantidade { get; set; }

        public Produto? Produto { get; set; }

        public double Valor_Item { get; set; }

        public Item(int quantidade, Produto produto)
        {

            this.Quantidade = quantidade;

            this.Produto = produto;

            this.Valor_Item = this.Quantidade * this.Produto.Preco;

        }

    }

}