﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consultas_Classe_Pedido
{

    class Pedido
    {

        public DateOnly Data_Pedido { get; set; }

        public Cliente? Cliente { get; set; }

        public List<Item> Itens { get; set; } = new List<Item>();

        public double Valor { get; set; }

        public Pedido(DateOnly data_pedido, Cliente cliente, List<Item> itens)
        {

            this.Data_Pedido = data_pedido;

            this.Cliente = cliente;

            this.Itens = itens;

            this.Valor = this.Itens.Select(item => new 
            {
                
                valor_individual_item = item.Valor_Item
            
            }).Sum(item => item.valor_individual_item);

        }

    }

}