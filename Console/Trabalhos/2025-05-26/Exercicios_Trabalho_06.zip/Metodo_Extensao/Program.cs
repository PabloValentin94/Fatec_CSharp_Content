﻿// Lista.

List<int> numeros = new List<int>() { 5, 12, 8, 20, 3, 15, 7 };

// Obtendo a soma dos números ímpares da lista.

int soma_numeros_impares = numeros.OddSum();

// Exibindo o resultado da soma.

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("SOMA DOS NÚMEROS ÍMPARES");

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("Resultado: {0}.", soma_numeros_impares);

Console.WriteLine("------------------------------------------------------------------------------------");

Console.ReadKey();

// Classe.

internal static class ListExtensions
{

    // Método de extensão.

    public static int OddSum(this IEnumerable<int> numbers)
    {

        int sum = 0;

        foreach (int number in numbers)
        {

            if (number % 2 == 1)
            {

                sum += number;

            }

        }

        return sum;

    }

}