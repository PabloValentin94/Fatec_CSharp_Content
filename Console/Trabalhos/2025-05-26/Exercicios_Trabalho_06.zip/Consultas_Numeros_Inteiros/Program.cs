﻿// Lista.

List<int> numeros = new List<int>() { 5, 12, 8, 20, 3, 15, 7 };

// Obtendo o maior valor da lista.

int maior_valor = numeros.Max();

// Somando os valores da lista maiores que 10.

int soma = numeros.Where(numero => numero > 10).Sum();

// Exibindo os resultados das consultas.

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("MAIOR VALOR");

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("Resultado: {0}.", maior_valor);

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("SOMA DOS NÚMEROS MAIORES QUE 10");

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("Resultado: {0}.", soma);

Console.WriteLine("------------------------------------------------------------------------------------");

Console.ReadKey();