﻿// Lista.

List<Pessoa> pessoas = new List<Pessoa>()
{

    new Pessoa("João", 17),
    new Pessoa("Maria", 22),
    new Pessoa("Carlos", 30),
    new Pessoa("Paulo", 14),
    new Pessoa("Beatriz", 45)

};

// Obtendo as pessoas da lista que possuem mais de 18 anos.

IEnumerable<Pessoa> pesquisa_pessoas = pessoas.Where(pessoa => pessoa.Idade > 18);

// Ordenando os nomes da lista em ordem alfabética.

IEnumerable<Pessoa> lista_pessoas_ordenada = pessoas.OrderBy(pessoa => pessoa.Nome);

// Exibindo os resultados das consultas.

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("PESSOAS COM MAIS DE 18 ANOS");

Console.Write("------------------------------------------------------------------------------------");

foreach (Pessoa pessoa in pesquisa_pessoas)
{

    Console.WriteLine($"\n- {pessoa.Nome} ({pessoa.Idade} anos.)");

}

Console.WriteLine("------------------------------------------------------------------------------------");

Console.WriteLine("LISTAGEM EM ORDEM ALFABÉTICA");

Console.Write("------------------------------------------------------------------------------------");

foreach (Pessoa pessoa in lista_pessoas_ordenada)
{

    Console.WriteLine($"\n- {pessoa.Nome} ({pessoa.Idade} anos.)");

}

Console.WriteLine("------------------------------------------------------------------------------------");

Console.ReadKey();

// Classe.

internal class Pessoa
{

    public string? Nome { get; set; }

    public int Idade { get; set; }

    public Pessoa(string nome, int idade)
    {

        this.Nome = nome;

        this.Idade = idade;

    }

}