﻿// Especificando o caminho de um arquivo (As pastas não são criadas automaticamente.).

string path = @"C:\Users\0201392411022\Fatec\Arquivos\String\String.txt";

FileStream? arquivo = null;

StreamReader? leitor_arquivo = null;

try
{

    arquivo = new FileStream(path, FileMode.Open, FileAccess.Read);

    leitor_arquivo = new StreamReader(arquivo);

    string? conteudo_linha = null;

    Console.WriteLine("--------------------------------------------------------------------------");

    while ((conteudo_linha = leitor_arquivo.ReadLine()) != null)
    {

        Console.WriteLine(conteudo_linha);

    }

}

catch (Exception ex)
{

    Console.Clear();

    Console.WriteLine("--------------------------------------------------------------------------");

    Console.WriteLine($"Erro!\n\nSaída:\n\n{ex.Message}");

}

finally
{

    if (leitor_arquivo != null)
    {

        leitor_arquivo.Close();

    }

    if (arquivo != null)
    {

        arquivo.Close();

    }

    Console.WriteLine("--------------------------------------------------------------------------");

    Console.ReadKey();

}