﻿// Especificando o caminho de um arquivo (As pastas não são criadas automaticamente.).

string path = @"C:\Users\0201392411022\Fatec\Arquivos\String\String.txt";

try
{

    Console.WriteLine("--------------------------------------------------------------------------");

    // Criando um arquivo de texto.

    TextFile.Create(path, "Criando o arquivo.");

    Console.WriteLine("--------------------------------------------------------------------------");

    // Adicionando um texto a um arquivo já existente.

    TextFile.AddText(path, Environment.NewLine + Environment.NewLine + "Adicionando um texto ao arquivo.");

    Console.WriteLine("--------------------------------------------------------------------------");

    // Obtendo o texto de um arquivo existente.

    TextFile.Read(path);

    Console.WriteLine("--------------------------------------------------------------------------");

    // Obtendo a data e o horário em que o arquivo foi acessado pela última vez.

    TextFile.LastAccess(path);

    Console.WriteLine("--------------------------------------------------------------------------");

    // Obtendo a data e o horário em que o arquivo foi editado pela última vez.

    TextFile.LastWrite(path);

}

catch (Exception ex)
{

    Console.Clear();

    Console.WriteLine("--------------------------------------------------------------------------");

    Console.WriteLine($"Erro!\n\nSaída:\n\n{ex.Message}");

}

finally
{

    Console.WriteLine("--------------------------------------------------------------------------");

    Console.ReadKey();

}

// Classe.

internal class TextFile
{

    public static void Create(string path, string text)
    {

        // Verificando se o arquivo especificado já existe.

        if (!File.Exists(path))
        {

            try
            {

                File.WriteAllText(path, text);

                Console.WriteLine("Arquivo criado com sucesso!");

            }

            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

        else
        {

            Console.WriteLine("O arquivo já existe!");

        }

    }

    public static void AddText(string path, string text)
    {

        // Verificando se o arquivo especificado já existe.

        if (File.Exists(path))
        {

            try
            {

                File.AppendAllText(path, text);

                Console.WriteLine("Texto adicionado ao arquivo com sucesso!");

            }

            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

    }

    public static void Read(string path)
    {

        // Verificando se o arquivo especificado já existe.

        if (File.Exists(path))
        {

            try
            {

                Console.WriteLine("Conteúdo:\n\n" + File.ReadAllText(path));

            }

            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

    }

    public static void LastAccess(string path)
    {

        // Verificando se o arquivo especificado já existe.

        if (File.Exists(path))
        {

            try
            {

                Console.WriteLine("Última vez acessado: " + File.GetLastAccessTime(path).ToString("dd/MM/yyyy hh:mm:ss"));

            }

            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

    }

    public static void LastWrite(string path)
    {

        // Verificando se o arquivo especificado já existe.

        if (File.Exists(path))
        {

            try
            {

                Console.WriteLine("Última vez editado: " + File.GetLastWriteTime(path).ToString("dd/MM/yyyy hh:mm:ss"));

            }

            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

    }

}