﻿using System.Text.Json;

using System.Text.Json.Serialization;

// Execução.

Console.WriteLine("---------------------------------------------------------------------------------------");

Console.WriteLine("SERIALIZAÇÃO");

Console.WriteLine("---------------------------------------------------------------------------------------");

Pessoa pessoa = new Pessoa("Pablo", new DateTime(2006, 3, 23), "(14) 99159-6481");

string json = JsonSerializer.Serialize<Pessoa>(pessoa);

Console.WriteLine("JSON: " + json);

Console.WriteLine("---------------------------------------------------------------------------------------");

Console.WriteLine("DESSERIALIZAÇÃO");

Console.WriteLine("---------------------------------------------------------------------------------------");

string json_objeto = "{\"Nome\":\"Gabriel\",\"Data_Nascimento\":\"12/01/2007\",\"Celular\":\"(14) 3416-6736\"}";

Pessoa? objeto = JsonSerializer.Deserialize<Pessoa>(json_objeto);

Console.WriteLine("JSON: " + json_objeto);

Console.WriteLine("\nNome (Desserialização): " + objeto?.Nome + ".");

Console.WriteLine("---------------------------------------------------------------------------------------");

Console.ReadKey();

// Classe.

class Pessoa
{

    public string? Nome { get; set; }

    public string? Data_Nascimento { get; set; }

    [JsonIgnore]
    public int Idade { get; set; }

    public string? Celular { get; set; }

    /*
     
        A definição manual de um construtor vazio torna-se obrigatória a partir do momento 
        em que há algum outro construtor que possua parâmetros na sua definição. Caso isso 
        não seja feito, irão ocorrer erros ao efetuar desserializações de dados de objetos 
        JSON.

    */

    public Pessoa() { }

    public Pessoa(string nome, DateTime data_nascimento, string celular)
    {

        this.Nome = nome;

        this.Data_Nascimento = data_nascimento.ToString("dd/MM/yyyy");

        int dias_idade = DateTime.Now.Subtract(data_nascimento).Days;

        this.Idade = (dias_idade - (dias_idade % 365)) / 365;

        this.Celular = celular;

    }

}