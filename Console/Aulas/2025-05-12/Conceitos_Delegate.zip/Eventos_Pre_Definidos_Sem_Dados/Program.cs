﻿// Execução.

Pedido pedido = new Pedido();

pedido.Eventos += Email.Enviar;

pedido.Eventos += SMS.Enviar;

pedido.Criar();

Console.ReadKey();

// Classes.

internal class Pedido
{

    public Guid Id { get; set; }

    public event EventHandler? Eventos;

    public Pedido()
    {

        this.Id = Guid.NewGuid();

    }

    public void Criar()
    {

        Console.WriteLine("Criando um pedido...");

        if (Eventos != null)
        {

            this.Eventos.Invoke(this, EventArgs.Empty);

        }

        Console.WriteLine("\nPedido criado.");

    }

}

internal class Email
{

    public static void Enviar(object? sender, EventArgs e)
    {

        Pedido pedido_associado = (Pedido) sender;

        Console.WriteLine($"\nUm e-mail foi enviado ({pedido_associado.Id}).");

    }

}

internal class SMS
{

    public static void Enviar(object? sender, EventArgs e)
    {

        Pedido pedido_associado = (Pedido) sender;

        Console.WriteLine($"\nUm SMS foi enviado ({pedido_associado.Id}).");

    }

}