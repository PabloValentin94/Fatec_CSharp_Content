﻿// Execução.

Teste_Delegate delegate_primeira_maneira = new Teste_Delegate(Mensagem.Exibir);

delegate_primeira_maneira.Invoke("Teste 01."); // Primeira maneira.

Teste_Delegate delegate_segunda_maneira = Mensagem.Exibir;

delegate_segunda_maneira("Teste 02."); // Segunda maneira.

Teste_Delegate delegate_terceira_maneira = (string mensagem) => Console.WriteLine(mensagem);

// Terceira maneira.

Console.ReadKey();

// Delegate.

public delegate void Teste_Delegate(string mensagem);

// Classe.

internal class Mensagem
{

    public static void Exibir(string mensagem)
    {

        Console.WriteLine($"\n{mensagem}");

    }

}