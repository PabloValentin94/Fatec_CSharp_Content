﻿// Execução.

Pedido pedido = new Pedido();

pedido.Eventos += Email.Enviar;

pedido.Eventos += SMS.Enviar;

pedido.Criar();

Console.ReadKey();

// Delegate.

public delegate void Evento_Pedido();

// Classes.

internal class Pedido
{

    public event Evento_Pedido? Eventos;

    public void Criar()
    {

        Console.WriteLine("Criando um pedido...");

        if (this.Eventos != null)
        {

            this.Eventos.Invoke();

        }

        Console.WriteLine("\nPedido criado.");

    }

}

internal class Email
{

    public static void Enviar()
    {

        Console.WriteLine("\nUm e-mail foi enviado.");

    }

}

internal class SMS
{

    public static void Enviar()
    {

        Console.WriteLine("\nUm SMS foi enviado.");

    }

}