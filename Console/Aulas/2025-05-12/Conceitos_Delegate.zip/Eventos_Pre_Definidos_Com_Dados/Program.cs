﻿// Execução.

Pedido pedido = new Pedido();

Console.WriteLine("---------------------------------------------------------------------------------------------------");

Console.WriteLine("ID do pedido: {0}", pedido.Id.ToString("D"));

Console.WriteLine("---------------------------------------------------------------------------------------------------");

pedido.Criar("pablo.valentin@fatec.sp.gov.br", "(14) 99159-6481", "Pedido criado há poucos segundos.");

Console.WriteLine("---------------------------------------------------------------------------------------------------");

pedido.Alterar_Status("pablo.valentin@fatec.sp.gov.br", "(14) 99159-6481", "Pedido preparado.");

Console.WriteLine("---------------------------------------------------------------------------------------------------");

pedido.Alterar_Status("pablo.valentin@fatec.sp.gov.br", "(14) 99159-6481", "Pedido enviado.");

Console.WriteLine("---------------------------------------------------------------------------------------------------");

pedido.Alterar_Status("pablo.valentin@fatec.sp.gov.br", "(14) 99159-6481", "Pedido em transporte.");

Console.WriteLine("---------------------------------------------------------------------------------------------------");

pedido.Alterar_Status("pablo.valentin@fatec.sp.gov.br", "(14) 99159-6481", "Pedido entregue.");

Console.WriteLine("---------------------------------------------------------------------------------------------------");

Console.ReadKey();

// Classe de dados de eventos.

internal class PedidoEventArgs : EventArgs
{

    public string? Email { get; set; } = null;

    public string? Telefone { get; set; } = null;

    public string? Status { get; set; } = null;

}

// Classes.

internal class Pedido
{

    // ID criado apenas para fins de teste e visualização.

    private Guid _id = Guid.NewGuid();

    public Guid Id { get { return this._id; } }

    // Atributo de persistência do status.

    public string? Status_Pedido { get; set; } = null;

    // Gerenciadores de eventos.

    public event EventHandler<PedidoEventArgs>? OnCreatePedido;

    public event EventHandler<PedidoEventArgs>? OnChangeStatus;

    public Pedido()
    {

        // Eventos acionados ao criar um pedido.

        this.OnCreatePedido += Email.Enviar;

        this.OnCreatePedido += SMS.Enviar;

        this.OnCreatePedido += Status.Alterar;

        // Eventos acionados ao alterar o status de um pedido.

        this.OnChangeStatus += Email.Enviar;

        this.OnChangeStatus += SMS.Enviar;

        this.OnChangeStatus += Status.Alterar;

    }

    public void Criar(string email, string telefone, string status)
    {

        Console.WriteLine("Criando um pedido...");

        this.Status_Pedido = status;

        if (this.OnCreatePedido != null)
        {

            this.OnCreatePedido.Invoke(this, new PedidoEventArgs()
            {

                Email = email,

                Telefone = telefone,

                Status = this.Status_Pedido

            });

        }

        Console.WriteLine("\nPedido criado.");

    }

    public void Alterar_Status(string email, string telefone, string status)
    {

        Console.WriteLine("Alterando status do pedido...");

        this.Status_Pedido = status;

        if (this.OnChangeStatus != null)
        {

            this.OnChangeStatus.Invoke(this, new PedidoEventArgs()
            {

                Email = email,

                Telefone = telefone,

                Status = this.Status_Pedido

            });

        }

    }

    // Classe.

    internal class Status
    {

        public static void Alterar(object? sender, PedidoEventArgs e)
        {

            if (e.Status != null)
            {

                // Pedido? pedido_associado = (Pedido?) sender;

                Console.WriteLine($"\nO status do pedido foi alterado ({e.Status}).");

            }

        }

    }

}

internal class Email
{

    public static void Enviar(object? sender, PedidoEventArgs e)
    {

        if (e.Email != null)
        {

            // Pedido? pedido_associado = (Pedido?) sender;

            Console.WriteLine($"\nUm e-mail foi enviado ({e.Email}).");

        }

    }

}

internal class SMS
{

    public static void Enviar(object? sender, PedidoEventArgs e)
    {

        if (e.Telefone != null)
        {

            // Pedido? pedido_associado = (Pedido?) sender;

            Console.WriteLine($"\nUm SMS foi enviado ({e.Telefone}).");

        }

    }

}