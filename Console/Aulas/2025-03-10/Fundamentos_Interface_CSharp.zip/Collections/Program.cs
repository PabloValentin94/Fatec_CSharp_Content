﻿using System.Collections.Generic;

// Objeto - IEnumerable.

Colecao_IEnumerable objeto_enumerable = new Colecao_IEnumerable();

Console.WriteLine("---------------------------------------------------------------");

List<string> list_exemplo_nomes = new List<string>() { "Pablo", "Gabriel" };

objeto_enumerable.Select(list_exemplo_nomes); // Acionando o método com um List

Console.WriteLine("---------------------------------------------------------------");

string[] array_exemplos_nomes  = ["Pablo", "Gabriel"];

objeto_enumerable.Select(array_exemplos_nomes); // Acionando o método com um array.

// Objeto - ICollection (Herda e evolui o IEnumerable. Possui métodos adicionais.).

Colecao_ICollection objeto_collection = new Colecao_ICollection();

ICollection<string> nomes = new List<string>() { "Pablo", "Gabriel" };

nomes.Add("Evandro"); // Adicionando um novo elemento.
nomes.Add("Vanessa"); // Adicionando um novo elemento.

Console.WriteLine("---------------------------------------------------------------");

objeto_collection.Select(nomes);

nomes.Remove("Evandro"); // Removendo um elemento.

Console.WriteLine("---------------------------------------------------------------");

objeto_collection.Select(nomes);
// objeto_enumerable.Select(nomes); // É possível passar uma ICollection como parâmetro para uma IEnumerable.

Console.WriteLine("---------------------------------------------------------------");

// Classes

public class Colecao_IEnumerable // IEnumerable.
{

    public void Select(IEnumerable<string> nomes)
    {

        foreach(string nome in nomes)
        {

            Console.WriteLine(nome);

        }

    }

}

public class Colecao_ICollection // ICollection.
{

    public void Select(ICollection<string> nomes)
    {

        foreach (string nome in nomes)
        {

            Console.WriteLine(nome);

        }

    }

}