﻿// Objeto (A tipagem referencia uma interface, não um classe.).

IAnimal objeto = new Cachorro();

// Método do objeto (Herança e Polimorfismo.).

objeto.Barulho();

// Interface.

public interface IAnimal
{

    public void Barulho();

}

// Classes.

public class Cachorro : IAnimal
{

    public void Barulho()
    {

        Console.WriteLine("Latir.");

    }

}

public class Gato : IAnimal
{

    public void Barulho()
    {

        Console.WriteLine("Miar.");

    }

}