﻿// Lista.

List<Produto> produtos = new List<Produto>()
{

    new Produto(1, "Camiseta Preta", 50.00, 20, "Roupas"),
    new Produto(2, "Camiseta Azul", 50.00, 50, "Roupas"),
    new Produto(3, "Smartphone", 1580.50, 5, "Eletrônicos"),
    new Produto(4, "Smartwatch", 299.99, 500, "Relógios"),
    new Produto(5, "Tablet", 1000.00, 300, "Eletrônicos")

};

// Execução.

try
{

    // Obtendo o último elemento da lista.

    Produto pesquisa = produtos.Last();

    Console.WriteLine("-----------------------------------------------------");

    Console.WriteLine("Item retornado: {0}.", pesquisa.Nome);

    // Obtendo o último elemento da lista, cujo nome seja igual ao informado.

    pesquisa = produtos.Last(produto => produto.Nome == "Camisa");

    Console.WriteLine("-----------------------------------------------------");

    Console.WriteLine("Item retornado: {0}.", pesquisa.Nome);

}

catch (Exception ex)
{

    /*
    
        Caso o programa tente acessar algum recurso do elemento retornado, mas 
        ele seja nulo, ou seja, nenhum foi encontrado na lista, é gerada uma exceção.

    */

    Console.WriteLine("-----------------------------------------------------");

    Console.WriteLine($"Erro! Saída: {ex.Message}.");

}

finally
{

    Console.WriteLine("-----------------------------------------------------");

    Console.ReadKey();

}

// Classe.

class Produto
{

    public int Id { get; set; }

    public string? Nome { get; set; }

    public double Preco { get; set; }

    public int Estoque { get; set; }

    public string? Categoria { get; set; }

    public Produto(int id, string nome, double preco, int estoque, string categoria)
    {

        this.Id = id;

        this.Nome = nome;

        this.Preco = preco;

        this.Estoque = estoque;

        this.Categoria = categoria;

    }

}