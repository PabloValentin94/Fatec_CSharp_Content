﻿// Lista.

List<Produto> produtos = new List<Produto>()
{

    new Produto(1, "Camiseta Preta", 50.00, 20, "Roupas"),
    new Produto(2, "Camiseta Azul", 50.00, 50, "Roupas"),
    new Produto(3, "Smartphone", 1580.50, 5, "Eletrônicos"),
    new Produto(4, "Smartwatch", 299.99, 500, "Relógios"),
    new Produto(5, "Tablet", 1000.00, 300, "Eletrônicos")

};

// Execução.

IEnumerable<IGrouping<string?, Produto>> produtos_categorias = produtos.GroupBy(produto => produto.Categoria);

Console.WriteLine("---------------------------------------------------------------------------");

Console.WriteLine("GROUP BY");

Console.Write("---------------------------------------------------------------------------");

foreach (IGrouping<string?, Produto> produtos_categoria in produtos_categorias)
{

    Console.WriteLine("\n" + produtos_categoria.Key + ":");

    foreach (Produto produto in produtos_categoria)
    {

        Console.WriteLine("\n    - {0}", produto.Nome);

    }

}

var produtos_categorias_select = produtos.GroupBy(produto => produto.Categoria).OrderBy(produtos_categoria_select => produtos_categoria_select.Key).Select(produtos_categoria_select => new
{

    Categoria = produtos_categoria_select.Key,

    Produtos_Ordenados = produtos_categoria_select.OrderBy(produto => produto.Nome).Select(produto => new
    {

        Nome = produto.Nome,

        Estoque = produto.Estoque,

        Preco = produto.Preco

    })

});

Console.WriteLine("---------------------------------------------------------------------------");

Console.WriteLine("GROUP BY + ORDER BY + SELECT");

Console.Write("---------------------------------------------------------------------------");

foreach (var produtos_categoria_select in produtos_categorias_select)
{

    Console.WriteLine("\n" + produtos_categoria_select.Categoria + ":");

    foreach (var produto in produtos_categoria_select.Produtos_Ordenados)
    {

        Console.WriteLine($"\n    - {produto.Nome} ({produto.Preco.ToString("C2")}) | {produto.Estoque} unidade(s) disponível(is)");

    }

}

Console.WriteLine("---------------------------------------------------------------------------");

Console.ReadKey();

// Classe.

class Produto
{

    public int Id { get; set; }

    public string? Nome { get; set; }

    public double Preco { get; set; }

    public int Estoque { get; set; }

    public string? Categoria { get; set; }

    public Produto(int id, string nome, double preco, int estoque, string categoria)
    {

        this.Id = id;

        this.Nome = nome;

        this.Preco = preco;

        this.Estoque = estoque;

        this.Categoria = categoria;

    }

}