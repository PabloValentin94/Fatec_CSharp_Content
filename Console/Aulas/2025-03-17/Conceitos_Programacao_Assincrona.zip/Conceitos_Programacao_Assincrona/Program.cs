﻿Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("EXECUÇÃO SÍNCRONA");

Console.WriteLine("---------------------------------------------------------------");

Cafe_Manha.Preparar_Cafe_Manha(); // Executando de forma síncrona/sequencial.

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("EXECUÇÃO ASSÍNCRONA");

Console.WriteLine("---------------------------------------------------------------");

await Cafe_Manha.Preparar_Cafe_Manha_Async(); // Executando de forma assíncrona (A execução não é necessariamente em ordem.).

Console.WriteLine("---------------------------------------------------------------");

// Classes.

class Pao
{

    public static Pao Preparar_Pao()
    {

        Console.WriteLine("\nCortando o pão;");

        Thread.Sleep(2000);

        Console.WriteLine("Passando margarina no pão;");

        Thread.Sleep(3000);

        Console.WriteLine("Torrando o pão.");

        Thread.Sleep(2000);

        return new Pao();

    }

    public static async Task<Pao> Preparar_Pao_Async()
    {

        Console.WriteLine("Cortando o pão;");

        await Task.Delay(2000);

        Console.WriteLine("Passando margarina no pão;");

        await Task.Delay(3000);

        Console.WriteLine("Torrando o pão.");

        await Task.Delay(2000);

        return new Pao();

    }

}

class Cafe
{

    public static Cafe Preparar_Cafe()
    {

        Console.WriteLine("\nFervendo a água;");

        Thread.Sleep(2000);

        Console.WriteLine("Coando o café;");

        Thread.Sleep(3000);

        Console.WriteLine("Adoçando o café.");

        Thread.Sleep(2000);

        return new Cafe();

    }

    public static async Task<Cafe> Preparar_Cafe_Async()
    {

        Console.WriteLine("Fervendo a água;");

        await Task.Delay(2000);

        Console.WriteLine("Coando o café;");

        await Task.Delay(3000);

        Console.WriteLine("Adoçando o café.");

        await Task.Delay(2000);

        return new Cafe();

    }

}

class Cafe_Manha
{

    public static void Preparar_Cafe_Manha()
    {

        Console.WriteLine("Preparando café da manhã...");

        Pao pao = Pao.Preparar_Pao();

        Cafe cafe = Cafe.Preparar_Cafe();

        Cafe_Manha.Servir_Cafe_Manha(pao, cafe);

    }

    public static async Task Preparar_Cafe_Manha_Async()
    {

        Console.WriteLine("Preparando café da manhã...\n");

        // Obtendo as Tasks e só então aguardando seus respectivos retornos.

        Task<Pao> task_pao = Pao.Preparar_Pao_Async();

        Task<Cafe> task_cafe = Cafe.Preparar_Cafe_Async();

        Pao pao = await task_pao;

        Cafe cafe = await task_cafe;

        // Aguardando e obtendo o retorno das Tasks diretamente.

        /*
         
            Pao pao = await Pao.Preparar_Pao_Async();

            Cafe cafe = await Cafe.Preparar_Cafe_Async();

         */

        Cafe_Manha.Servir_Cafe_Manha(pao, cafe);

    }

    public static void Servir_Cafe_Manha(Pao pao, Cafe cafe)
    {

        Console.WriteLine("\nServindo café da manhã...");

        Thread.Sleep(5000);

        Console.WriteLine("\nCafé da manhã servido.");

    }

    public static void Servir_Cafe_Manha_Async(Pao pao, Cafe cafe)
    {

        Servir_Cafe_Manha(pao, cafe);

    }

}