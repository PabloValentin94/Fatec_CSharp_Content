﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacao_Objetos
{

    public class Produto
    {

        public int Id { get; set; }

        public string? Nome { get; set; }

        public double Preco { get; set; }

        public int Estoque { get; set; }

        public string? Categoria { get; set; }

        public Produto(int id, string nome, double preco, int estoque, string categoria)
        {

            this.Id = id;

            this.Nome = nome;

            this.Preco = preco;

            this.Estoque = estoque;

            this.Categoria = categoria;

        }

        public static List<Produto> Get_Produtos()
        {

            List<Produto> produtos = new List<Produto>()
            {

                new Produto(1, "Camiseta Preta", 50.00, 20, "Roupas"),
                new Produto(2, "Camiseta Azul", 50.00, 50, "Roupas"),
                new Produto(3, "Smartphone", 1580.50, 5, "Eletrônicos"),
                new Produto(4, "Smartwatch", 299.99, 500, "Relógios"),
                new Produto(5, "Tablet", 1000.00, 300, "Eletrônicos")

            };

            return produtos;

        }

    }

}