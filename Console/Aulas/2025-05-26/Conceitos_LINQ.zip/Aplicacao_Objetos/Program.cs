﻿using Aplicacao_Objetos;

// Obtendo objetos.

List<Produto> produtos = Produto.Get_Produtos();

Console.WriteLine("-----------------------------------------------------");

// Filtrando objetos.

IEnumerable<Produto> pesquisa_produtos = produtos.Where(produto => produto.Categoria == "Eletrônicos");

// Listando os itens da pesquisa.

foreach (Produto produto in pesquisa_produtos)
    Console.WriteLine($"\n{produto.Nome} | {produto.Preco.ToString("C2")}");

Console.WriteLine("\n-----------------------------------------------------");

// Filtrando objetos.

IEnumerable<Produto> pesquisa_produtos_caros = produtos.Where(produto => produto.Preco >= 1000.00 && produto.Estoque < 10).OrderBy(produto => produto.Nome);

// Listando os itens da pesquisa.

foreach (Produto produto in pesquisa_produtos_caros)
    Console.WriteLine($"\n{produto.Nome} | {produto.Preco.ToString("C2")} | {produto.Estoque}");

Console.WriteLine("\n-----------------------------------------------------");

// Filtrando objetos.

IEnumerable<Produto> pesquisa_produtos_ordenados = produtos.OrderBy(produto => produto.Nome).ThenBy(produto => produto.Categoria);

// Listando os itens da pesquisa.

foreach (Produto produto in pesquisa_produtos_ordenados)
    Console.WriteLine($"\n{produto.Nome} | {produto.Categoria}");

Console.WriteLine("\n-----------------------------------------------------");

double valor_disponivel_mercadorias = produtos.Where(produto => produto.Estoque > 0).Sum(produto => produto.Preco * produto.Estoque);

Console.WriteLine("\nValor disponível em mercadorias: " + valor_disponivel_mercadorias.ToString("C2"));

Console.WriteLine("\n-----------------------------------------------------");

double media_preco_produto = produtos.Where(produto => produto.Categoria == "Eletrônicos").Average(produto => produto.Preco);

Console.WriteLine("\nMédia de preço dos eletrônicos: " + media_preco_produto.ToString("C2"));

Console.WriteLine("\n-----------------------------------------------------");

var pesquisa_produtos_faixa_percentual = produtos.Where(produto => produto.Preco < 500).OrderBy(produto => produto.Nome).Select(produto => new {

    Nome_Normalizado = produto.Nome?.ToUpper(),

    Preco_Ajustado = produto.Preco * 1.10

});

foreach (var produto in pesquisa_produtos_faixa_percentual)
    Console.WriteLine($"\n{produto.Nome_Normalizado} | {produto.Preco_Ajustado.ToString("C2")}");

Console.WriteLine("\n-----------------------------------------------------");

Console.ReadKey();