﻿Console.WriteLine("-----------------------------------------------------");

int[] numeros = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

// Expressão lambda.

IEnumerable<int> numeros_pares_lambda = from numero in numeros where numero % 2 == 0 select numero;

// Método.

IEnumerable<int> numeros_pares_metodo = numeros.Where(numero => numero % 2 == 0);

// Listando os itens dos array.

foreach (int numero_par in numeros_pares_metodo)
    Console.WriteLine("\n" + numero_par);

Console.WriteLine("\n-----------------------------------------------------");

List<string> nomes = new List<string>()
{

    "Pablo",
    "Gabriel",
    "Evandro",
    "Vanessa"

};

// Expressão lambda.

IEnumerable<string> pesquisa_nomes_lambda = from nome in nomes where nome.ToLower().Contains('a') select nome;

// Método.

IEnumerable<string> pesquisa_nomes_metodo = nomes.Where(nome => nome.ToLower().Contains('a'));

// Listando os itens da lista.

foreach (string nome in pesquisa_nomes_metodo)
    Console.WriteLine("\n" + nome);

Console.WriteLine("\n-----------------------------------------------------");

Console.ReadKey();