﻿/*
 
    Agregação:

    - Dois objetos se relacionam, mas não dependenm um do outro (Se um for apagado, o outro ainda permanece.);

    - As instâncias são separadas.

*/

/*
 
    Composição:

    - A parte (Dependente) só existe enquanto o todo (Independente) existir;

    - A parte geralmente é instanciada dentro (Internamente) do todo.

*/

Carro carro = new Carro("Fiat", "Uno (Escada)", 150000000, "Lendário");

carro.Detalhes();

Pessoa pessoa = new Pessoa("Pablo Valentin", 14, "99159-1529");

pessoa.Adicionar_Celular(14, "99159-6481");

pessoa.Detalhes();