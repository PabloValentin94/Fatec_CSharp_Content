﻿// Classes.

public class Pessoa
{

    public string? Nome { get; set; }

    public List<Celular> Celulares { get; set; } = new List<Celular>();

    public Pessoa(string nome, int ddd, string digitos)
    {

        this.Nome = nome;

        this.Adicionar_Celular(ddd, digitos);

    }

    public void Adicionar_Celular(int ddd, string digitos)
    {

        this.Celulares.Add(new Celular(ddd, digitos));

    }

    public void Detalhes()
    {

        Console.WriteLine("PESSOA");

        Console.WriteLine("------------------------------------------------------------------");

        Console.WriteLine($"Nome: {this.Nome}.");

        Console.WriteLine("\nCelulares:\n");

        foreach (Celular celular in this.Celulares)
        {

            Console.WriteLine($"({celular.DDD}) {celular.Digitos}");

        }

        Console.WriteLine("------------------------------------------------------------------");

    }

    // Classe.

    public class Celular
    {

        public int DDD { get; set; }

        public string? Digitos { get; set; }

        public Celular(int ddd, string digitos)
        {

            this.DDD = ddd;

            this.Digitos = digitos;

        }

    }

}