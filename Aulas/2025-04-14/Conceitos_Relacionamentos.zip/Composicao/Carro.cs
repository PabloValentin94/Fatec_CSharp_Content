﻿// Classes.

public class Carro
{

    public string? Marca { get; set; }

    public string? Modelo { get; set; }

    public Motor MotorCarro { get; set; }

    public Carro(string marca, string modelo, int potencia, string tipo)
    {

        this.Marca = marca;

        this.Modelo = modelo;

        this.MotorCarro = new Motor(potencia, tipo);

    }

    public void Detalhes()
    {

        Console.WriteLine("------------------------------------------------------------------");

        Console.WriteLine("CARRO");

        Console.WriteLine("------------------------------------------------------------------");

        Console.WriteLine($"Marca: {this.Marca};" +
                          $"\n\nModelo: {this.Modelo};" +
                          $"\n\nPotência (Motor): {this.MotorCarro.Potencia};" +
                          $"\n\nTipo (Motor): {this.MotorCarro.Tipo}.");

        Console.WriteLine("------------------------------------------------------------------");

    }

    // Classe.

    public class Motor
    {

        public int Potencia { get; set; }

        public string? Tipo { get; set; }

        public Motor(int potencia, string tipo)
        {

            this.Potencia = potencia;

            this.Tipo = tipo;

        }

    }

}