﻿// Bloco de execução padrão.

try
{

    Console.Write("Digite um número: ");
    int dividendo = int.Parse(Console.ReadLine());

    Console.Write("\nDigite outro número: ");
    int divisor = int.Parse(Console.ReadLine());

    int resultado = dividendo / divisor;

    Console.WriteLine($"\nResultado: {resultado}");

}

// Blocos de tratamento e exibição de exceções (Erros.).

catch (FormatException)
{

    Console.WriteLine("\nErro: insira um número válido!");

}

catch (OverflowException)
{

    Console.WriteLine("\nErro: o número informado excedeu o limite máximo permitido!");

}

catch (DivideByZeroException)
{

    Console.WriteLine("\nErro: não é permitido divisão por zero!");

}

catch (Exception ex)
{

    Console.WriteLine("\nErro: " + ex.Message);

}

// Bloco de execução obrigatória (Sempre é executado, tendo ocorridos erros ou não.).

finally
{

    Console.ReadKey();

}