﻿// string[] array = new string[] { "Teste" };

// string[] array = new string[5] { "P", "A", "B", "L", "O" };

string[] array = { "P", "A", "B", "L", "O" };

Console.WriteLine("---------------------------------------------------------------");

// Exibindo os itens do array.

foreach (string valor in array)
{

    Console.WriteLine(valor);

}

Console.WriteLine("---------------------------------------------------------------");

// Invertendo a ordem dos itens do array.

Array.Reverse(array);

// Exibindo os itens do array.

foreach (string valor in array)
{

    Console.WriteLine(valor);

}

Console.WriteLine("---------------------------------------------------------------");

// Ordenando o array (Por padrão, ordem alfabética.).

Array.Sort(array);

// Exibindo os itens do array.

foreach (string valor in array)
{

    Console.WriteLine(valor);

}

Console.WriteLine("---------------------------------------------------------------");

// Procurando no array, entre os índices X e Y, o elemento cujo valor for igual ao especificado.

int indice_valor = Array.BinarySearch(array, 0, 5, "P");

// Exibindo o índice do item encontrado.

Console.WriteLine(indice_valor);

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();