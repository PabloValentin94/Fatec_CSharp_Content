﻿// Uma expressão lambda consiste em usar uma função anônima para executar um método ou função.

List<string> lista = new List<string>() { "Pablo", "Evandro", "Gabriel", "Vanessa" };

Console.WriteLine("---------------------------------------------------------------");

// Usando uma expressão lambda como parâmetro para o método executado.

Console.WriteLine(lista.Find(texto => { return texto.Contains("Gab"); }));

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();