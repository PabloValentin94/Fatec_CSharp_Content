﻿// int[,] tabela = new int[2, 2];

int[,] tabela_imutavel = new int[2, 2] { {1, 2}, { 3, 4 } }; // Neste caso o número de "casas" das dimensões não é dinâmico.

// Exibindo os itens do array multidimensional.

for (int i = 0; i < tabela_imutavel.GetLength(0); i++) // Percorre as linhas do array multidimensional.
{

    Console.WriteLine("---------------------------------------------------------------");

    for (int j = 0; j < tabela_imutavel.GetLength(1); j++) // Percorre as colunas do array multidimensional.
    {

        // Exibindo o item atual do looping.

        Console.WriteLine(tabela_imutavel[i, j].ToString());

    }

}

Console.WriteLine("---------------------------------------------------------------");

// Exibindo a quantidade de itens do array multidimensional.

Console.WriteLine($"Quantidade de itens da tabela: {tabela_imutavel.Length}.");

Console.WriteLine("---------------------------------------------------------------");

// Obtendo um item do array multidimensional através de suas posições dimensionais.

object valor_pesquisa = tabela_imutavel.GetValue(0, 1) ?? "Nenhum valor encontrado";

// Exibindo o item encontrado no array multidimensional.

Console.WriteLine($"Valor encontrado: {valor_pesquisa}.");

int[][] tabela_dinamica = new int[][] { [0,1,2,3], [4,5], [6], [7,8,9] }; // Neste caso o número de "casas" das dimensões é dinâmico.

// Exibindo os itens do array multidimensional.

for (int i = 0; i < tabela_dinamica.Length; i++)
{

    Console.WriteLine("---------------------------------------------------------------");

    for (int j = 0; j < tabela_dinamica[i].Length; j++)
    {

        // Exibindo o item atual do looping.

        Console.WriteLine(tabela_dinamica[i][j].ToString());

    }

}

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();