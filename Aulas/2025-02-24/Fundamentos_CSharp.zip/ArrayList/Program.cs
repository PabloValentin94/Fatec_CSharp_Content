﻿using System.Collections;

// ArrayList lista_varios_tipos = new ArrayList(5);

// var lista_varios_tipos = new ArrayList(5);

// ArrayList lista_varios_tipos = new(5);

ArrayList lista_varios_tipos = new ArrayList();

Console.WriteLine("---------------------------------------------------------------");

// Adicionando um item ao final da lista.

lista_varios_tipos.Add(10);

// Exibindo os itens da lista.

for (int i = 0; i < lista_varios_tipos.Count; i++)
{

    Console.WriteLine(lista_varios_tipos[i]);

}

Console.WriteLine("---------------------------------------------------------------");

// Adicionando vários itens ao final da lista.

lista_varios_tipos.AddRange(new string[] { "Pablo", "Valentin" });

// Exibindo os itens da lista.

for (int i = 0; i < lista_varios_tipos.Count; i++)
{

    Console.WriteLine(lista_varios_tipos[i]);

}

Console.WriteLine("---------------------------------------------------------------");

// Adicionando um item no índice da lista especificado (Os itens serão reposicionados para que não haja perdas.).

lista_varios_tipos.Insert(0, 5);

// Exibindo os itens da lista.

for (int i = 0; i < lista_varios_tipos.Count; i++)
{

    Console.WriteLine(lista_varios_tipos[i]);

}

Console.WriteLine("---------------------------------------------------------------");

// Adicionando vários itens no índice da lista especificado (Os itens serão reposicionados para que não haja perdas.).

lista_varios_tipos.InsertRange(2, new string[] { "Teste", "Prático" });

// Exibindo os itens da lista.

for (int i = 0; i < lista_varios_tipos.Count; i++)
{

    Console.WriteLine(lista_varios_tipos[i]);

}

Console.WriteLine("---------------------------------------------------------------");

// Removendo o item especificado da lista.

lista_varios_tipos.Remove(5);

// Exibindo os itens da lista.

for (int i = 0; i < lista_varios_tipos.Count; i++)
{

    Console.WriteLine(lista_varios_tipos[i]);

}

Console.WriteLine("---------------------------------------------------------------");

// Removendo Y itens da lista, a partir do índice X.

lista_varios_tipos.RemoveRange(0, 2); // (X,Y)

// Exibindo os itens da lista.

for (int i = 0; i < lista_varios_tipos.Count; i++)
{

    Console.WriteLine(lista_varios_tipos[i]);

}

Console.WriteLine("---------------------------------------------------------------");

// Removendo o item da lista cujo índice for igual ao especificado.

lista_varios_tipos.RemoveAt(0);

// Exibindo os itens da lista.

for (int i = 0; i < lista_varios_tipos.Count; i++)
{

    Console.WriteLine(lista_varios_tipos[i]);

}

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();