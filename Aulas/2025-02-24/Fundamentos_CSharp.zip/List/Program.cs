﻿// var lista = new List<string>();

// List<string> lista = new();

// List<string> lista = new List<string>();

List<string> lista = new List<string>() { "Pablo", "Evandro", "Gabriel", "Vanessa" };

Console.WriteLine("---------------------------------------------------------------");

// Verificando se esse texto está presente como um valor dentro da lista.

Console.WriteLine(lista.Contains("Teste"));

Console.WriteLine("---------------------------------------------------------------");

// Ordenando a lista (Por padrão, ordem alfabética.).

lista.Sort();

// Exibindo os itens da lista.

foreach (string valor in lista)
{

    Console.WriteLine(valor);

}

Console.WriteLine("---------------------------------------------------------------");

// Obtendo o primeiro item da lista que contiver a letra "a".

Console.WriteLine(lista.Find(texto => { return texto.Contains('a'); }));

Console.WriteLine("---------------------------------------------------------------");

// Obtendo o último item da lista que contiver a letra "a".

Console.WriteLine(lista.FindLast(texto => { return texto.Contains('a'); }));

Console.WriteLine("---------------------------------------------------------------");

// Obtendo o índice do primeiro item da lista que contiver a letra "a".

Console.WriteLine(lista.FindIndex(texto => { return texto.Contains('a'); }));

Console.WriteLine("---------------------------------------------------------------");

// Obtendo o índice do último item da lista que contiver a letra "a".

Console.WriteLine(lista.FindLastIndex(texto => { return texto.Contains('a'); }));

Console.WriteLine("---------------------------------------------------------------");

// Obtendo todos os itens da lista que contiverem a letra "o".

List<string> valores = lista.FindAll(texto => { return texto.Contains('o'); });

// Exibindo todos os itens da lista que atenderam à condição anterior.

foreach (string valor in valores)
{

    Console.WriteLine(valor);

}

Console.WriteLine("---------------------------------------------------------------");

// Excluindo todos os itens da lista.

lista.Clear();

Console.ReadKey();