﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progamacao_Orientada_Objetos
{

    public class Produto
    {

        public string? nome { get; set; }

        private double? preco; // Campo que armazena o valor do preço.

        public double? Preco {
            
            get { return preco; }
            
            set { preco = value - 10.00; }

        } // Atributo responsável por retornar ou modificar o valor do campo preço.

        public double desconto { get { return 0; } } // Atributo soemente leitura.

        private int estoque_minimo;

        public int Estoque_Minimo { set { estoque_minimo = value - 5; } } // Atributo somente gravação.

        public double preco_final { get; set; }

        public Produto(string? nome)
        {

            this.nome = nome;

        }

        // Sobrecarga de construtores.

        public Produto(string? nome, double preco, double desconto, int estoque_minimo) : this(nome)
        {

            // this.nome = nome;
            this.Preco = preco; // Mudança implícita.
            // this.desconto = desconto;
            this.Estoque_Minimo = estoque_minimo;
            this.preco_final = preco - desconto;

        }

        // Método estático (Não depende de um objeto para ser executado.).

        public static void Exibir(Produto produto)
        {

            Console.WriteLine(
                    $"Nome: {produto.nome}" +
                    $"\nPreço: {produto.preco.ToString()}" +
                    $"\nDesconto: {produto.desconto.ToString("c")}" +
                    // $"\nEstoque Mínimo: {produto.estoque_minimo}" +
                    $"\nPreço Final: {produto.preco_final.ToString("c")}"
                );

        }

    }

}
