﻿using Progamacao_Orientada_Objetos;

Produto produto = new Produto("Camiseta", 50.00, 5.00, 100);

Produto.Exibir(produto);