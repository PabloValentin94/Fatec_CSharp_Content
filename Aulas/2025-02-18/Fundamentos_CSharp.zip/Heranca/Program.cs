﻿Gato gato = new Gato("Wiskas");

Cachorro cachorro = new Cachorro("Rufus");

Console.WriteLine("---------------------------------------------------------------");

gato.Miar();

Console.WriteLine("---------------------------------------------------------------");

cachorro.Latir();

Console.WriteLine("---------------------------------------------------------------");

public class Animal
{

    protected string nome { get; set; }

    public Animal(string nome)
    {

        this.nome = nome;

    }

}

public class Gato : Animal
{

    public Gato(string nome) : base(nome) {  }

    public void Miar()
    {

        Console.WriteLine(this.nome + " está miando!");

    }

}

public class Cachorro : Animal
{

    public Cachorro(string nome) : base(nome) { }

    public void Latir()
    {

        Console.WriteLine(this.nome + " está latindo!");

    }

}