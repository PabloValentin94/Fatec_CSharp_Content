﻿Produto produto = new Produto("Camiseta", 50.00, 5.00, 100);

// Não precisa ser necessariamente na mesma ordem de parâmetros, desde que se use os identificadores.

Produto teste_fora_ordem = new Produto(preco: 150.00, desconto: 20.00, nome: "Jaqueta", estoque_minimo: 30);

Console.WriteLine("---------------------------------------------------------------");

Produto.Exibir(produto); // Executando método estático.

Console.WriteLine("---------------------------------------------------------------");

Produto.Exibir(teste_fora_ordem); // Executando método estático.

Console.WriteLine("---------------------------------------------------------------");

public class Produto
{

    public string? nome { get; set; }

    public double preco { get; set; }

    public double desconto { get; set; }

    public int estoque_minimo { get; set; }

    public double preco_final { get; set; }

    public Produto(string? nome)
    {

        this.nome = nome;

    }

    // Sobrecarga de construtores.

    public Produto(string? nome, double preco, double desconto, int estoque_minimo) : this(nome)
    {

        // this.nome = nome;
        this.preco = preco;
        this.desconto = desconto;
        this.estoque_minimo = estoque_minimo;
        this.preco_final = preco - desconto;

    }

    // Método estático (Não depende de um objeto para ser executado.).

    public static void Exibir(Produto produto)
    {

        Console.WriteLine(
                $"Nome: {produto.nome}" +
                $"\nPreço: {produto.preco.ToString("c")}" +
                $"\nDesconto: {produto.desconto.ToString("c")}" +
                $"\nEstoque Mínimo: {produto.estoque_minimo}" +
                $"\nPreço Final: {produto.preco_final.ToString("c")}"
            );

    }

}