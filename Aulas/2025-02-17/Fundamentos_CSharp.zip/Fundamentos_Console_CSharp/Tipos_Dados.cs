﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fundamentos_Console_CSharp
{

    internal class Tipos_Dados
    {

        public static void Main()
        {

            string variavel_string = "Teste";

            int variavel_int = 94;

            double variavel_double = 100.50;

            float variavel_float = 100.50f;

            decimal variavel_decimal = 100.50m;

            int[] variavel_array = [1, 2, 10, 14];

            Console.WriteLine(variavel_string);

        }

    }

}
