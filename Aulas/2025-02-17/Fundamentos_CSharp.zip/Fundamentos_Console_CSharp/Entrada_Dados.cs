﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fundamentos_Console_CSharp
{

    internal class Entrada_Dados
    {

        public static void Main()
        {

            Console.WriteLine("Digite um número:");
            float primeiro_numero = float.Parse(Console.ReadLine());

            Console.WriteLine("Digite outro número:");
            float segundo_numero = float.Parse(Console.ReadLine());

            Console.WriteLine("Soma: " + (primeiro_numero + segundo_numero).ToString("C2"));

        }

    }

}
