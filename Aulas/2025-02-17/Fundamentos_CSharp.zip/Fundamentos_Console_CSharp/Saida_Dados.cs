﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fundamentos_Console_CSharp
{

    internal class Saida_Dados
    {

        public static void Main()
        {

            string texto = "Teste";

            // Exibir uma mensagem na tela.

            Console.WriteLine(texto);

            // Concatenação de textos.

            Console.WriteLine("Mensagem de " + texto + ".");

            // Interpolação de variável.

            Console.WriteLine($"Mensagem de {texto}.");

        }

    }

}