﻿/*

        Disciplina: Técnicas de Programação II.
        Professora: Vânia Somaio Teixeira.
        Descrição: calcule o IMC do usuário utilizando estruturas de condição.
        Autor(a): Pablo Valentin.
        Data atual: 17/02/2025

        Faça um algoritmo que calcule o IMC (Índice de Massa Corporal) com base nos
        dados obtidos.

        IMC:                    CLASSIFICAÇÃO:          OBESIDADE (GRAU):

        MENOR QUE 18,5          MAGREZA                 Nenhuma
        ENTRE 18,5 E 24,9       NORMAL                  Nenhuma
        ENTRE 25,0 E 29,9       SOBREPESO               I
        ENTRE 30,0 E 39,9       OBESIDADE               II
        MAIOR QUE 40,0          OBESIDADE GRAVE         III

 */

Console.WriteLine("---------------------------------------------------------------");

Console.WriteLine("SISTEMA - IMC");

Console.WriteLine("---------------------------------------------------------------");

Console.Write("Digite seu nome: ");
string nome = null ?? "Usuário(a)";

Console.Write("\nDigite seu peso, em kilos: ");
double peso = double.Parse(Console.ReadLine());
//double peso = Convert.ToDouble(Console.ReadLine());

Console.Write("\nDigite sua altura, em metros: ");
double altura = double.Parse(Console.ReadLine());
//double altura = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("---------------------------------------------------------------");

double imc = peso / Math.Pow(altura, 2);

string classificacao;

if (imc < 18.5)
    classificacao = "Magreza";
else if (imc >= 18.5 && imc < 25)
    classificacao = "Normal";
else if (imc > -25 && imc < 30)
    classificacao = "Sobrepeso";
else if (imc >= 30 && imc < 40)
    classificacao = "Obesidade";
else
    classificacao = "Obesidade Grave";

Console.WriteLine($"{nome}, sua classificação do IMC ({Math.Round(imc, 2)}) é: {classificacao}.");

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();