﻿Calculadora calculadora = new Calculadora();
//var calculadora = new Calculadora();
//Calculadora calculadora = new();

Console.WriteLine("---------------------------------------------------------------");

calculadora.Divisao([2, 10, 2]);

Console.WriteLine("---------------------------------------------------------------");

Console.ReadKey();

public class Calculadora
{

    // O C# aceita métodos com mesmo nome, contanto que a quantidade, o nome ou o tipo dos parâmetros não sejam iguais.

    public void Soma(double[] numeros)
    {

        double soma = 0;

        foreach (double numero in numeros)
            soma += numero;

        Console.WriteLine($"Soma = {soma}");

    }

    public void Subtracao(double[] numeros)
    {

        double diferenca = numeros[0];

        numeros[0] = 0;

        foreach (double numero in numeros)
            diferenca -= numero;

        Console.WriteLine($"Subtração = {diferenca}");

    }

    public void Multiplicacao(double[] numeros)
    {

        double produto = numeros[0];

        numeros[0] = 1;

        foreach (double numero in numeros)
            produto *= numero;

        Console.WriteLine($"Multiplicação = {produto}");

    }

    public void Divisao(double[] numeros)
    {

        double quociente = numeros[0];

        numeros[0] = 1;

        foreach (double numero in numeros)
            quociente /= numero;

        Console.WriteLine($"Divisão = {quociente}");

    }

}