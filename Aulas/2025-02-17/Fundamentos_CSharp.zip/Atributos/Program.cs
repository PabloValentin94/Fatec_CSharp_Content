﻿Produto produto = new Produto()
{

    nome = "Camiseta",
    preco = 50.00,
    desconto = 5.00,
    estoque_minimo = 100

};

produto.preco_final = produto.preco - produto.desconto;

Console.WriteLine("---------------------------------------------------------------");

produto.Exibir();

Console.WriteLine("---------------------------------------------------------------");

public class Produto
{

    public string? nome { get; set; }

    public double preco { get; set; }

    public double desconto { get; set; }

    public int estoque_minimo { get; set; }

    public double preco_final { get; set; }

    public void Exibir()
    {

        Console.WriteLine(
                $"Nome: {this.nome}" +
                $"\nPreço: {this.preco.ToString("c")}" +
                $"\nDesconto: {this.desconto.ToString("c")}" +
                $"\nEstoque Mínimo: {this.estoque_minimo}" +
                $"\nPreço Final: {this.preco_final.ToString("c")}"
            );

    }

}