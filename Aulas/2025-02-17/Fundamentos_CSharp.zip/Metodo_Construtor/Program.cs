﻿Produto produto = new Produto("Camiseta", 50.00, 5.00, 100);

// Não precisa ser necessariamente na mesma ordem de parâmetros, desde que se use os identificadores.

Produto teste_fora_ordem = new Produto(preco: 150.00, desconto: 20.00, nome: "Jaqueta", estoque_minimo: 30);

Console.WriteLine("---------------------------------------------------------------");

produto.Exibir();

Console.WriteLine("---------------------------------------------------------------");

teste_fora_ordem.Exibir();

Console.WriteLine("---------------------------------------------------------------");

public class Produto
{

    public string? nome { get; set; }

    public double preco { get; set; }

    public double desconto { get; set; }

    public int estoque_minimo { get; set; }

    public double preco_final { get; set; }

    public Produto(string? nome, double preco, double desconto, int estoque_minimo)
    {

        this.nome = nome;
        this.preco = preco;
        this.desconto = desconto;
        this.estoque_minimo = estoque_minimo;
        this.preco_final = preco - desconto;

    }

    public void Exibir()
    {

        Console.WriteLine(
                $"Nome: {this.nome}" +
                $"\nPreço: {this.preco.ToString("c")}" +
                $"\nDesconto: {this.desconto.ToString("c")}" +
                $"\nEstoque Mínimo: {this.estoque_minimo}" +
                $"\nPreço Final: {this.preco_final.ToString("c")}"
            );

    }

}